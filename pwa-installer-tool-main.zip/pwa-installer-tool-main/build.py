"""
Build script for creating Windows executable
Run this script to package the application
"""

import PyInstaller.__main__
import os
import shutil


def clean_build_dirs():
    """Clean previous build directories"""
    dirs_to_clean = ['dist', 'build']
    for dir_name in dirs_to_clean:
        if os.path.exists(dir_name):
            print(f"Cleaning {dir_name}/...")
            shutil.rmtree(dir_name)


def build_executable():
    """Build the executable using PyInstaller"""
    print("Building PWA Installer Tool executable...")
    print("-" * 50)
    
    # Clean previous builds
    clean_build_dirs()
    
    # PyInstaller arguments
    args = [
        'pwa_installer.py',
        '--onefile',                    # Single executable
        '--windowed',                   # No console window
        '--name=PWA-Installer',
        '--hidden-import=PIL',
        '--hidden-import=PIL._tkinter_finder',
        '--collect-all=tkinter',
        '--optimize=2',
        '--clean',
    ]
    
    # Add icon if it exists
    if os.path.exists('assets/icon.ico'):
        args.append('--icon=assets/icon.ico')
    
    # Build
    PyInstaller.__main__.run(args)
    
    print("-" * 50)
    print("Build complete!")
    print(f"Executable location: {os.path.abspath('dist/PWA-Installer.exe')}")
    print(f"File size: {os.path.getsize('dist/PWA-Installer.exe') / (1024*1024):.2f} MB")


if __name__ == "__main__":
    build_executable()
