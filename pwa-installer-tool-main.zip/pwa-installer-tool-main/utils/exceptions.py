"""Custom exceptions with user-friendly messages"""


class PWAInstallerError(Exception):
    """Base exception with user-friendly messages"""
    pass


class ManifestNotFoundError(PWAInstallerError):
    def __init__(self):
        self.message = "This zip doesn't contain a valid PWA. Missing manifest.json file."
        super().__init__(self.message)


class ManifestInvalidError(PWAInstallerError):
    def __init__(self):
        self.message = "The PWA's manifest.json file is corrupted or invalid."
        super().__init__(self.message)


class PortUnavailableError(PWAInstallerError):
    def __init__(self):
        self.message = "Cannot start server. Please close other applications and try again."
        super().__init__(self.message)


class BrowserNotFoundError(PWAInstallerError):
    def __init__(self, browser_name: str = "Selected browser"):
        self.message = f"{browser_name} not found. Please select a different browser."
        super().__init__(self.message)
