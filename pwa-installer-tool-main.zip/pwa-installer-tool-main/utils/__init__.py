"""Utility package for PWA Installer Tool"""
