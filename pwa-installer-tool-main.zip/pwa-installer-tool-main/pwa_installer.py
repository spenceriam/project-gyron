"""
PWA Installer Tool
Main entry point for the application
"""

import sys
import tkinter as tk


def check_environment():
    """Check if running in correct environment with dependencies"""
    missing_deps = []
    
    # Check for required dependencies
    try:
        import PIL
    except ImportError:
        missing_deps.append("Pillow")
    
    try:
        import tkinterdnd2
    except ImportError:
        missing_deps.append("tkinterdnd2")
    
    if missing_deps:
        print("\n" + "="*60)
        print("ERROR: Missing required dependencies")
        print("="*60)
        print(f"\nMissing: {', '.join(missing_deps)}")
        print("\nThis usually means the virtual environment is not activated.")
        print("\nTo fix this:")
        print("  1. Activate the virtual environment:")
        print("     .\\venv\\Scripts\\Activate.ps1")
        print("  2. Run the application again:")
        print("     python pwa_installer.py")
        print("\nOR install dependencies globally:")
        print("     pip install -r requirements.txt")
        print("="*60 + "\n")
        return False
    
    return True


def main():
    """Main entry point"""
    # Check environment before importing GUI
    if not check_environment():
        sys.exit(1)
    
    # Import after environment check to avoid confusing errors
    from gui.main_window import PWAInstallerGUI
    
    try:
        app = PWAInstallerGUI()
        app.run()
    except Exception as e:
        # Show error dialog if GUI fails to start
        root = tk.Tk()
        root.withdraw()
        tk.messagebox.showerror("Error", f"Failed to start application: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()
