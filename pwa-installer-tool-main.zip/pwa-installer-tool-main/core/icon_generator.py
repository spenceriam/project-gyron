"""Icon generation with gradient and text overlay"""

import os
from PIL import Image, ImageDraw, ImageFont
from urllib.parse import urlparse
from typing import Dict


class IconGenerator:
    """Generate PWA icons with improved gradient and precise centered letter.

    Gradient now runs top→bottom for clearer visual brand (blue at top fading to teal at bottom).
    Centering uses anchor-based rendering when available to eliminate minor font metric offsets.
    """
    
    # Color constants
    GRADIENT_START = (0, 0, 255)      # Blue
    GRADIENT_END = (0, 128, 128)      # Teal
    TEXT_COLOR = (255, 255, 255)       # White
    
    def __init__(self, manifest: Dict, base_path: str):
        """
        Initialize icon generator
        
        Args:
            manifest: Parsed manifest.json dictionary
            base_path: Base path where PWA files are located
        """
        self.manifest = manifest
        self.base_path = base_path
        self.letter = self._extract_letter()
    
    def _extract_letter(self) -> str:
        """
        Get first letter from PWA name or start_url
        
        Returns:
            Single uppercase letter for icon
        """
        name = None
        
        # Priority: name, short_name, start_url domain
        if 'name' in self.manifest and self.manifest['name']:
            name = self.manifest['name']
        elif 'short_name' in self.manifest and self.manifest['short_name']:
            name = self.manifest['short_name']
        elif 'start_url' in self.manifest:
            parsed = urlparse(self.manifest['start_url'])
            domain = parsed.netloc or parsed.path
            name = domain.split('.')[0] if domain else 'P'
        
        # Get first alphanumeric character
        if name:
            for char in name:
                if char.isalnum():
                    return char.upper()
        
        return 'P'  # Default fallback
    
    def generate_missing_icons(self):
        """Create all missing icons from manifest (only if they don't already exist)."""
        icons = self.manifest.get('icons', [])
        
        for icon_entry in icons:
            icon_src = icon_entry.get('src', '')
            if not icon_src:
                continue
            
            # Remove leading slash if present
            if icon_src.startswith('/'):
                icon_src = icon_src[1:]
            
            icon_path = os.path.join(self.base_path, icon_src)
            
            # Only generate if icon doesn't exist
            if not os.path.exists(icon_path):
                size = self._parse_size(icon_entry.get('sizes', '512x512'))
                self._generate_icon(icon_path, size)
    
    def _parse_size(self, sizes_str: str) -> int:
        """
        Parse size string like '512x512' to integer
        
        Args:
            sizes_str: Size string from manifest (e.g., "512x512", "192x192 256x256")
            
        Returns:
            Integer size (width/height, assumes square)
        """
        # Take first size if multiple
        size_parts = sizes_str.split()[0].split('x')
        try:
            return int(size_parts[0])
        except (ValueError, IndexError):
            return 512  # Default fallback
    
    def _generate_icon(self, icon_path: str, size: int):
        """
        Generate single icon with gradient and text
        
        Args:
            icon_path: Full path where icon should be saved
            size: Icon size in pixels (square)
        """
        # Create gradient background
        img = self._create_gradient(size)
        
        # Add text overlay
        img = self._add_text(img, self.letter, size)
        
        # Ensure directory exists
        os.makedirs(os.path.dirname(icon_path), exist_ok=True)
        
        # Save icon as PNG
        img.save(icon_path, 'PNG')

    def regenerate_all_icons(self):
        """Force regeneration of all icons declared in manifest (overwrite existing)."""
        icons = self.manifest.get('icons', [])
        for icon_entry in icons:
            icon_src = icon_entry.get('src', '')
            if not icon_src:
                continue
            if icon_src.startswith('/'):
                icon_src = icon_src[1:]
            icon_path = os.path.join(self.base_path, icon_src)
            size = self._parse_size(icon_entry.get('sizes', '512x512'))
            try:
                self._generate_icon(icon_path, size)
            except Exception as e:
                print(f"[IconGen] Failed to regenerate {icon_src}: {e}")
    
    def _create_gradient(self, size: int) -> Image.Image:
        """Create a smooth vertical blue→teal gradient (top blue, bottom teal)."""
        top = self.GRADIENT_START
        bottom = self.GRADIENT_END
        img = Image.new('RGB', (size, size))
        px = img.load()
        for y in range(size):
            ratio = y / (size - 1)
            r = int(top[0] + ratio * (bottom[0] - top[0]))
            g = int(top[1] + ratio * (bottom[1] - top[1]))
            b = int(top[2] + ratio * (bottom[2] - top[2]))
            for x in range(size):
                px[x, y] = (r, g, b)
        return img
    
    def _add_text(self, img: Image.Image, letter: str, size: int) -> Image.Image:
        """
        Add centered white letter to image
        
        Args:
            img: PIL Image to draw on
            letter: Single letter to display
            size: Image size in pixels
            
        Returns:
            PIL Image with text overlay
        """
        draw = ImageDraw.Draw(img)
        font_size = int(size * 0.6)  # 60% of icon size
        
        # Try to load Arial Bold, fallback to Arial, then default
        font = None
        try:
            font = ImageFont.truetype("arialbd.ttf", font_size)
        except:
            try:
                font = ImageFont.truetype("arial.ttf", font_size)
            except:
                try:
                    # Try system font paths
                    font = ImageFont.truetype("C:\\Windows\\Fonts\\arialbd.ttf", font_size)
                except:
                    try:
                        font = ImageFont.truetype("C:\\Windows\\Fonts\\arial.ttf", font_size)
                    except:
                        # Use default font as last resort
                        font = ImageFont.load_default()
        
        # Prefer anchor-based true center if Pillow supports it
        try:
            draw.text((size/2, size/2), letter, fill=self.TEXT_COLOR, font=font, anchor="mm")
        except Exception:
            # Fallback to bbox centering
            bbox = draw.textbbox((0, 0), letter, font=font)
            text_width = bbox[2] - bbox[0]
            text_height = bbox[3] - bbox[1]
            x = (size - text_width) / 2 - bbox[0]
            y = (size - text_height) / 2 - bbox[1]
            draw.text((round(x), round(y)), letter, fill=self.TEXT_COLOR, font=font)
        
        return img
