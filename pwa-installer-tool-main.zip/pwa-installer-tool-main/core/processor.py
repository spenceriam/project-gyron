"""PWA processing logic"""

import os
import json
import zipfile
import tempfile
import shutil
from urllib.parse import urlparse
from typing import Optional, Dict
from utils.exceptions import ManifestNotFoundError, ManifestInvalidError


class PWAProcessor:
    """Handles PWA zip extraction and validation"""
    
    def __init__(self):
        self.temp_dir: Optional[str] = None
        self.manifest: Optional[Dict] = None
        self.pwa_name: Optional[str] = None
        self.extracted_path: Optional[str] = None
    
    def extract_zip(self, zip_path: str) -> str:
        """
        Extract zip to temporary directory
        
        Args:
            zip_path: Path to zip file
            
        Returns:
            Path to extracted directory
            
        Raises:
            ValueError: If zip contains invalid paths
        """
        self.temp_dir = tempfile.mkdtemp(prefix="pwa_installer_")
        
        try:
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                # Security: validate paths to prevent path traversal
                for member in zip_ref.namelist():
                    if member.startswith('/') or '..' in member:
                        raise ValueError("Zip contains invalid paths")
                    
                    # Ensure path stays within temp directory
                    target_path = os.path.join(self.temp_dir, member)
                    if not target_path.startswith(os.path.abspath(self.temp_dir)):
                        raise ValueError("Zip contains invalid paths")
                
                zip_ref.extractall(self.temp_dir)
            
            self.extracted_path = self.temp_dir
            return self.temp_dir
            
        except Exception as e:
            self.cleanup()
            raise
    
    def validate_manifest(self, extracted_path: str) -> Dict:
        """
        Find and validate manifest.json
        
        Args:
            extracted_path: Path to extracted PWA directory
            
        Returns:
            Parsed manifest dictionary
            
        Raises:
            ManifestNotFoundError: If manifest.json not found
            ManifestInvalidError: If manifest.json is invalid JSON
        """
        # Check root directory
        manifest_path = os.path.join(extracted_path, 'manifest.json')
        
        if not os.path.exists(manifest_path):
            # Check one level deep (if zip has single folder)
            for item in os.listdir(extracted_path):
                item_path = os.path.join(extracted_path, item)
                if os.path.isdir(item_path):
                    manifest_path = os.path.join(item_path, 'manifest.json')
                    if os.path.exists(manifest_path):
                        self.extracted_path = item_path
                        break
            else:
                raise ManifestNotFoundError()
        
        # Parse JSON
        try:
            with open(manifest_path, 'r', encoding='utf-8') as f:
                self.manifest = json.load(f)
            return self.manifest
        except json.JSONDecodeError:
            raise ManifestInvalidError()
    
    def get_pwa_name(self) -> str:
        """
        Extract PWA name from manifest
        
        Returns:
            PWA name from manifest
            
        Priority: name > short_name > start_url domain > "PWA"
        """
        if not self.manifest:
            return "Unknown PWA"
        
        # Priority: name, short_name, start_url domain
        if 'name' in self.manifest and self.manifest['name']:
            self.pwa_name = self.manifest['name']
        elif 'short_name' in self.manifest and self.manifest['short_name']:
            self.pwa_name = self.manifest['short_name']
        elif 'start_url' in self.manifest:
            parsed = urlparse(self.manifest['start_url'])
            domain = parsed.netloc or parsed.path
            self.pwa_name = domain.split('.')[0] if domain else "PWA"
        else:
            self.pwa_name = "PWA"
        
        return self.pwa_name
    
    def cleanup(self):
        """Remove temporary files and directories"""
        if self.temp_dir and os.path.exists(self.temp_dir):
            try:
                shutil.rmtree(self.temp_dir)
            except Exception as e:
                # Log warning but don't fail - OS will cleanup eventually
                print(f"Warning: Failed to cleanup temp directory: {e}")
            finally:
                self.temp_dir = None
                self.extracted_path = None
