"""Core processing package for PWA Installer Tool"""
