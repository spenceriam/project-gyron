"""Browser detection and launching"""

import os
import subprocess
from typing import Dict, List, Optional
from utils.exceptions import BrowserNotFoundError


class BrowserLauncher:
    """Detect and launch browsers"""
    
    # Standard Windows browser installation paths
    BROWSER_PATHS = {
        'Microsoft Edge': [
            r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
            r'C:\Program Files\Microsoft\Edge\Application\msedge.exe'
        ],
        'Google Chrome': [
            r'C:\Program Files\Google\Chrome\Application\chrome.exe',
            r'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe',
            os.path.expanduser(r'~\AppData\Local\Google\Chrome\Application\chrome.exe')
        ],
        'Mozilla Firefox': [
            r'C:\Program Files\Mozilla Firefox\firefox.exe',
            r'C:\Program Files (x86)\Mozilla Firefox\firefox.exe'
        ],
        'Brave': [
            r'C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe',
            r'C:\Program Files (x86)\BraveSoftware\Brave-Browser\Application\brave.exe',
            os.path.expanduser(r'~\AppData\Local\BraveSoftware\Brave-Browser\Application\brave.exe')
        ]
    }
    
    def __init__(self):
        """Initialize browser launcher and detect available browsers"""
        self.available_browsers = self._detect_browsers()
    
    def _detect_browsers(self) -> Dict[str, str]:
        """
        Detect installed browsers by checking standard paths
        
        Returns:
            Dictionary mapping browser names to executable paths
        """
        found = {}
        for name, paths in self.BROWSER_PATHS.items():
            for path in paths:
                if os.path.exists(path):
                    found[name] = path
                    break
        return found
    
    def get_browser_names(self) -> List[str]:
        """
        Get list of available browser names
        
        Returns:
            List of detected browser names
        """
        return list(self.available_browsers.keys())
    
    def get_default_browser(self) -> Optional[str]:
        """
        Get default browser (prefer Edge, then Chrome, then others)
        
        Returns:
            Browser name or None if no browsers found
        """
        # Priority: Edge > Chrome > Firefox > Brave
        priority = ['Microsoft Edge', 'Google Chrome', 'Mozilla Firefox', 'Brave']
        
        for browser in priority:
            if browser in self.available_browsers:
                return browser
        
        # If none of the priority browsers found, return first available
        if self.available_browsers:
            return list(self.available_browsers.keys())[0]
        
        return None
    
    def launch(self, browser_name: str, url: str):
        """
        Launch browser with URL
        
        Args:
            browser_name: Name of browser to launch
            url: URL to open
            
        Raises:
            BrowserNotFoundError: If browser not found
        """
        if browser_name not in self.available_browsers:
            raise BrowserNotFoundError(browser_name)
        
        browser_path = self.available_browsers[browser_name]
        
        # Launch browser without blocking
        try:
            subprocess.Popen([browser_path, url])
        except Exception as e:
            raise BrowserNotFoundError(f"{browser_name} (launch failed: {str(e)})")
