"""HTTP server management for PWA installation"""

import os
import socket
import threading
import http.server
from typing import Optional
from utils.exceptions import PortUnavailableError


class PWARequestHandler(http.server.SimpleHTTPRequestHandler):
    """Custom HTTP handler serving static install page and redirect shell."""
    
    def __init__(self, *args, directory=None, **kwargs):
        self.directory = directory
        super().__init__(*args, directory=directory, **kwargs)
    
    def do_GET(self):
        """Serve landing page at dedicated path or static assets with optional sanitisation"""
        print(f"[Server] REQUEST: {self.path}", flush=True)
        
        # Shell page that redirects to remote URL after PWA install
        if self.path == '/_shell.html':
            html = self._create_shell_page()
            content = html.encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', len(content))
            self.send_header('Cache-Control', 'no-cache')
            self.end_headers()
            self.wfile.write(content)
            remote_base = getattr(self.server, 'remote_base', 'UNKNOWN')
            print(f"[Server] Served shell redirect page -> {remote_base}", flush=True)
            return
        
        # Dedicated install landing page path (no redirects here)
        if self.path in ['/__install__', '/', '/index.html']:
            manifest_path = os.path.join(self.directory, 'manifest.json')
            app_name = 'PWA'
            manifest = {}
            if os.path.exists(manifest_path):
                try:
                    import json
                    with open(manifest_path, 'r', encoding='utf-8') as f:
                        manifest = json.load(f)
                    app_name = manifest.get('name') or manifest.get('short_name') or 'PWA'
                    print(f"[Server] Landing page request for: {app_name}", flush=True)
                    # Remote discovery already performed in server manager
                except Exception as e:
                    print(f"[Server] Warning: manifest read failed: {e}", flush=True)
            else:
                print(f"[Server] Warning: manifest.json missing at {manifest_path}", flush=True)
            try:
                html = self._create_install_page(app_name, manifest)
                content = html.encode('utf-8')
                
                # Debug: Check if manifest link is in HTML
                if 'rel=\'manifest\'' in html:
                    print(f"[Server] ✓ Manifest link found in HTML", flush=True)
                else:
                    print(f"[Server] ✗ WARNING: No manifest link in HTML!", flush=True)
                
                self.send_response(200)
                self.send_header('Content-Type', 'text/html; charset=utf-8')
                self.send_header('Content-Length', len(content))
                self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
                self.send_header('Pragma', 'no-cache')
                self.send_header('Expires', '0')
                self.end_headers()
                self.wfile.write(content)
                print(f"[Server] Served landing page ({len(content)} bytes) at path {self.path}", flush=True)
                return
            except Exception as e:
                print(f"[Server] ERROR: Landing page generation failed: {e}", flush=True)
        
        # Sanitise service worker to prevent auto-navigation
        if self.path == '/sw.js':
            original_sw = os.path.join(self.directory, 'sw.js')
            if os.path.exists(original_sw):
                try:
                    sanitized = self._sanitize_service_worker(original_sw)
                    content = sanitized.encode('utf-8')
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/javascript; charset=utf-8')
                    self.send_header('Content-Length', len(content))
                    self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
                    self.end_headers()
                    self.wfile.write(content)
                    print(f"[Server] Served sanitized service worker ({len(content)} bytes)", flush=True)
                    return
                except Exception as e:
                    print(f"[Server] WARNING: Failed to sanitize sw.js: {e} - serving original", flush=True)
            else:
                print("[Server] sw.js not found; returning empty stub", flush=True)
            # Fallback empty stub
            stub = "self.addEventListener('install',()=>self.skipWaiting());self.addEventListener('activate',()=>clients.claim());".encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'application/javascript; charset=utf-8')
            self.send_header('Content-Length', len(stub))
            self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
            self.end_headers()
            self.wfile.write(stub)
            return
        
        # Manifest interception: force start_url to remote target
        if self.path == '/manifest.json' or self.path.startswith('/manifest.json?'):
            print(f"[Server] ========== MANIFEST REQUEST RECEIVED ==========", flush=True)
            manifest_path = os.path.join(self.directory, 'manifest.json')
            if os.path.exists(manifest_path):
                try:
                    import json
                    with open(manifest_path, 'r', encoding='utf-8') as f:
                        manifest = json.load(f)
                    original_start = manifest.get('start_url')
                    
                    # Build target URL from discovered remote base + relative start
                    remote_base = getattr(self.server, 'remote_base', None)
                    relative_start = getattr(self.server, 'manifest_relative_start', None) or ''
                    
                    print(f"[Server] DEBUG: remote_base={remote_base}, relative_start={relative_start}", flush=True)
                    
                    if remote_base:
                        # Keep start_url pointing to localhost shell page
                        # Shell page will redirect to remote URL after PWA opens
                        manifest['start_url'] = '/_shell.html'
                        manifest['scope'] = '/'
                        
                        # Add unique ID to force fresh install
                        import random
                        manifest['id'] = f"/?v={random.randint(100000, 999999)}"
                        
                        print(f"[Server] ✓ MANIFEST REWRITTEN: start_url=/_shell.html (will redirect to remote)", flush=True)
                    else:
                        print(f"[Server] ✗ ERROR: No remote base discovered, keeping original start_url={original_start}", flush=True)
                    
                    content = json.dumps(manifest, ensure_ascii=False).encode('utf-8')
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/json; charset=utf-8')
                    self.send_header('Content-Length', len(content))
                    self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
                    self.end_headers()
                    self.wfile.write(content)
                    return
                except Exception as e:
                    print(f"[Server] ERROR: Failed to serve manifest: {e}", flush=True)
            # Fallback 404
            self.send_error(404)
            return
        super().do_GET()
    
    def log_message(self, format, *args):
        """Suppress server logs"""
        pass

    def _sanitize_service_worker(self, path: str) -> str:
        """Return service worker that caches shell page so app works after server stops."""
        return (
            "// PWA Installer Tool SW\n"
            "const CACHE='pwa-installer-shell-v1';const SHELL='/_shell.html';\n"
            "console.log('[SW] Starting service worker');\n"
            "self.addEventListener('install',e=>{\n"
            "  console.log('[SW] Install event - caching shell page');\n"
            "  e.waitUntil(\n"
            "    caches.open(CACHE)\n"
            "      .then(c=>{\n"
            "        console.log('[SW] Cache opened, adding shell:', SHELL);\n"
            "        return c.add(SHELL);\n"
            "      })\n"
            "      .then(()=>{\n"
            "        console.log('[SW] Shell cached successfully');\n"
            "        return self.skipWaiting();\n"
            "      })\n"
            "      .catch(err=>{\n"
            "        console.error('[SW] Failed to cache shell:', err);\n"
            "        throw err;\n"
            "      })\n"
            "  );\n"
            "});\n"
            "self.addEventListener('activate',e=>{\n"
            "  console.log('[SW] Activate event');\n"
            "  e.waitUntil(self.clients.claim().then(()=>console.log('[SW] Clients claimed')));\n"
            "});\n"
            "self.addEventListener('fetch',e=>{\n"
            "  if(e.request.mode==='navigate'){\n"
            "    console.log('[SW] Navigation request:', e.request.url);\n"
            "    e.respondWith(\n"
            "      caches.match(SHELL)\n"
            "        .then(r=>{\n"
            "          if(r){\n"
            "            console.log('[SW] Serving cached shell');\n"
            "            return r;\n"
            "          }\n"
            "          console.log('[SW] Shell not in cache, fetching...');\n"
            "          return fetch(e.request).catch(()=>{\n"
            "            console.error('[SW] Fetch failed, serving fallback');\n"
            "            return new Response('<!doctype html><title>Launching</title><script>location.replace(\"'+SHELL+'\")</script>',{headers:{'Content-Type':'text/html; charset=utf-8'}});\n"
            "          });\n"
            "        })\n"
            "    );\n"
            "  }\n"
            "});\n"
        )

    def _create_install_page(self, app_name: str, manifest: dict) -> str:
        import time
        cache_bust = int(time.time())
        icon_url = '/icons/icon-192.png'
        if 'icons' in manifest and manifest.get('icons'):
            icon_url = manifest['icons'][0].get('src', icon_url)
        return f"""<!DOCTYPE html>
<html lang='en'>
<head>
  <meta charset='UTF-8'>
  <title>Install {app_name}</title>
  <meta name='viewport' content='width=device-width,initial-scale=1'>
  <meta http-equiv='Cache-Control' content='no-cache, no-store, must-revalidate'>
  <meta http-equiv='Pragma' content='no-cache'>
  <meta http-equiv='Expires' content='0'>
  <link rel='manifest' href='/manifest.json?v={cache_bust}'>
  <link rel='icon' href='{icon_url}'>
  <style>
    body {{margin:0;font-family:Segoe UI,Arial,sans-serif;background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);color:#fff;min-height:100vh;display:flex;align-items:center;justify-content:center;}}
    .panel {{background:rgba(255,255,255,0.08);padding:26px 34px;border-radius:22px;width:clamp(320px,70%,640px);box-shadow:0 10px 36px rgba(0,0,0,0.35);}}
    h1 {{margin:0 0 14px;font-size:30px;font-weight:600;}}
    ol {{padding-left:22px;margin:0;}}
    li {{margin:7px 0;}}
    img.icon {{width:110px;height:110px;border-radius:28px;box-shadow:0 8px 28px rgba(0,0,0,0.4);margin-bottom:18px;}}
    p.desc {{line-height:1.5;font-size:15px;margin:0 0 14px;}}
    .small {{margin-top:10px;font-size:11px;opacity:.65;}}
    #installBtn {{margin-top:18px;padding:12px 20px;border:none;border-radius:10px;background:#22c55e;color:#fff;font-weight:600;font-size:15px;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,.3);}}
    #installBtn:hover {{filter:brightness(1.08);}}
    #installBtn:disabled {{opacity:0.5;cursor:not-allowed;}}
    #statusMsg {{margin-top:14px;font-size:13px;opacity:.8;}}
  </style>
</head>
<body>
  <div class='panel'>
    <img src='{icon_url}' alt='' class='icon' onerror="this.style.display='none'">
    <h1>{app_name}</h1>
    <p class='desc'>Use the browser's <strong>Install App</strong> control OR the green button below when it appears. This page stays put so scripts cannot redirect before you install.</p>
    <ol>
      <li>Wait for the green Install button OR use the address bar install icon.</li>
      <li>Confirm installation.</li>
            <li>Open the installed app from Start / Apps. It will then launch the real application.</li>
        </ol>
        <button id='installBtn' disabled>Install Application</button>
        <div id='statusMsg'>Waiting for install eligibility…</div>
        <div class='small'>Origin: localhost:{self.server.server_port} • Installation Landing</div>
    </div>
    <script>
        let deferredPrompt=null;
        const installBtn=document.getElementById('installBtn');
        const statusMsg=document.getElementById('statusMsg');
        console.log('[Install] Page loaded, waiting for beforeinstallprompt...');
        window.addEventListener('beforeinstallprompt', (e)=>{{
            console.log('[Install] beforeinstallprompt event fired!');
            e.preventDefault();
            deferredPrompt=e;
            installBtn.disabled=false;
            statusMsg.textContent='Ready to install.';
        }});
        installBtn.addEventListener('click', async ()=>{{
            console.log('[Install] Button clicked, deferredPrompt:', deferredPrompt);
            if(!deferredPrompt) return;
            deferredPrompt.prompt();
            const choice = await deferredPrompt.userChoice;
            if(choice.outcome==='accepted') {{ statusMsg.textContent='Installation accepted. You can close this window.'; }}
            else {{ statusMsg.textContent='Installation dismissed. You can try again.'; }}
            deferredPrompt=null;
        }});
        if('serviceWorker' in navigator) {{ 
            console.log('[Install] Registering service worker...');
            navigator.serviceWorker.register('/sw.js')
                .then(reg=>console.log('[Install] SW registered:', reg))
                .catch(err=>console.error('[Install] SW registration failed:', err)); 
        }}
        setTimeout(()=>{{ 
            if(!deferredPrompt) {{
                console.log('[Install] Timeout - beforeinstallprompt not fired yet');
                statusMsg.textContent='Use browser address bar install icon OR wait for green button...';
                installBtn.disabled=false;
                installBtn.textContent='Install from Address Bar →';
            }}
        }},2500);
    </script>
</body>
</html>"""

    def _create_shell_page(self) -> str:
        remote_base = getattr(self.server, 'remote_base', None)
        relative_start = getattr(self.server, 'manifest_relative_start', None) or ''
        if relative_start.startswith('./'):
            relative_start = relative_start[1:]
        target = ''
        if remote_base:
            target = remote_base + (relative_start if relative_start.startswith('/') else ('/' + relative_start)) if relative_start else remote_base
        return f"""<!DOCTYPE html>
<html lang='en'>
<head>
  <meta charset='UTF-8'>
  <title>Launching {remote_base or 'application'}...</title>
  <meta name='viewport' content='width=device-width,initial-scale=1'>
  <style>
    body {{margin:0;font-family:Segoe UI,Arial,sans-serif;background:#121212;color:#eee;display:flex;align-items:center;justify-content:center;min-height:100vh;}}
    .box {{text-align:center;background:#1e1e1e;padding:32px 40px;border-radius:24px;box-shadow:0 8px 30px rgba(0,0,0,0.55);width:clamp(320px,60%,600px);}}
    h2 {{margin:0 0 12px;font-size:26px;font-weight:600;}}
    .spin {{width:70px;height:70px;border:8px solid rgba(255,255,255,0.25);border-top-color:#fff;border-radius:50%;animation:spin 1s linear infinite;margin:16px auto;}}
    @keyframes spin {{to {{transform:rotate(360deg);}}}}
    .url {{font-size:12px;word-break:break-all;opacity:.8;margin-top:10px;}}
    button {{margin-top:18px;padding:10px 18px;border:none;border-radius:8px;background:#ffb300;color:#222;font-weight:600;cursor:pointer;}}
    button:hover {{filter:brightness(1.08);}}
    .fallback {{margin-top:20px;font-size:12px;opacity:.7;}}
  </style>
</head>
<body>
  <div class='box'>
    <div class='spin'></div>
    <h2>Launching...</h2>
    <div class='url'>{target or 'Target URL not auto-detected'}</div>
    <button id='openBtn' style='{'' if target else 'display:none;'}'>Open Now</button>
    <div id='manualWrap' style='{'' if target else ''}'>
      <p class='fallback'>Enter full https URL if not detected:</p>
      <input id='manual' type='text' placeholder='https://example.com/app' style='width:75%;padding:7px 10px;border-radius:8px;border:none;'>
      <button id='manualGo' style='padding:8px 14px;margin-left:8px;border:none;border-radius:8px;background:#4caf50;color:#fff;font-weight:600;'>Go</button>
    </div>
  </div>
  <script>
    let target = {target!r};
    console.log('[Shell] Target URL:', target);
    function attempt() {{
      if(!target) {{
        console.error('[Shell] No target URL - cannot redirect');
        return;
      }}
      console.log('[Shell] Attempting redirect to:', target);
      try {{ window.location.replace(target); }} catch(e) {{ console.error('[Shell] Redirect failed', e); }}
    }}
    if(target) {{ 
      console.log('[Shell] Scheduling redirects...');
      setTimeout(attempt, 600); 
      setTimeout(attempt, 1600); 
      setTimeout(attempt, 3000); 
    }} else {{
      console.warn('[Shell] No target URL detected - showing manual input');
    }}
    document.getElementById('openBtn')?.addEventListener('click', attempt);
    document.getElementById('manualGo')?.addEventListener('click', () => {{
        const val = document.getElementById('manual').value.trim();
        if(!val) return;
        target = val.startsWith('http') ? val : ('https://' + val);
        document.querySelector('.url').textContent = target;
        document.getElementById('openBtn').style.display='inline-block';
        attempt();
    }});
  </script>
</body>
</html>"""


class PWAServerManager:
    """Manages HTTP server lifecycle and remote target discovery"""
    PORT_RANGE = range(8000, 8010)

    def __init__(self, pwa_directory: str):
        self.directory = pwa_directory
        self.port: Optional[int] = None
        self.server = None
        self.server_thread = None
        self.remote_base: Optional[str] = None
        self.manifest_relative_start: Optional[str] = None
    
    def start(self) -> int:
        """
        Start server on available port
        
        Returns:
            Port number server is running on
            
        Raises:
            PortUnavailableError: If no ports available
        """
        self.port = self._find_available_port()
        
        # Create server with custom handler
        def handler_factory(*args, **kwargs):
            return PWARequestHandler(*args, directory=self.directory, **kwargs)
        
        self.server = http.server.HTTPServer(('localhost', self.port), handler_factory)
        # Discover remote base & manifest relative start_url
        self._discover_remote_context()
        self.server.remote_base = self.remote_base
        self.server.manifest_relative_start = self.manifest_relative_start
        
        # Start server in background thread
        self.server_thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.server_thread.start()
        
        return self.port
    
    def _find_available_port(self) -> int:
        """
        Find first available port in range
        
        Returns:
            Available port number
            
        Raises:
            PortUnavailableError: If all ports busy
        """
        for port in self.PORT_RANGE:
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.bind(('localhost', port))
                    return port
            except OSError:
                continue
        
        raise PortUnavailableError()

    def _discover_remote_context(self):
        """Scan files to find first absolute https:// domain and capture manifest relative start_url."""
        # Capture manifest relative start_url
        manifest_path = os.path.join(self.directory, 'manifest.json')
        if os.path.exists(manifest_path):
            try:
                import json
                with open(manifest_path, 'r', encoding='utf-8') as f:
                    manifest = json.load(f)
                start_url = manifest.get('start_url')
                if isinstance(start_url, str) and start_url and not start_url.startswith('http://') and not start_url.startswith('https://'):
                    self.manifest_relative_start = start_url
            except Exception:
                pass
        # Scan limited set of file types for absolute https:// domain
        import re
        domain_pattern = re.compile(r'https://([a-zA-Z0-9.-]+)')
        candidates = []
        for root, _, files in os.walk(self.directory):
            for name in files:
                if not name.lower().endswith(('.js', '.html', '.json', '.txt', '.css')):
                    continue
                file_path = os.path.join(root, name)
                try:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        text = f.read()
                    for m in domain_pattern.finditer(text):
                        host = m.group(1)
                        if host not in ['localhost', '127.0.0.1']:
                            candidates.append(host)
                            if len(candidates) > 50:  # safety break
                                break
                    if candidates:
                        break
                except Exception:
                    continue
            if candidates:
                break
        if candidates:
            # pick first (could be improved with heuristics later)
            self.remote_base = f'https://{candidates[0]}'
        print(f"[Server] Remote discovery: base={self.remote_base} relative_start={self.manifest_relative_start}", flush=True)
    
    def stop(self):
        """Stop server and cleanup without blocking"""
        if self.server:
            try:
                # Shutdown in background to avoid blocking GUI thread
                def _shutdown():
                    try:
                        self.server.shutdown()
                    except:
                        pass
                
                import threading
                shutdown_thread = threading.Thread(target=_shutdown, daemon=True)
                shutdown_thread.start()
            except:
                pass
            self.server = None
        
        # Don't wait for server thread - let daemon cleanup handle it
        self.server_thread = None
