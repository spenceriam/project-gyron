# PWA Installer Tool Launcher
# This script automatically activates the virtual environment and runs the app

Write-Host "PWA Installer Tool Launcher" -ForegroundColor Cyan
Write-Host "============================`n" -ForegroundColor Cyan

# Check if venv exists
if (-not (Test-Path ".\venv\Scripts\Activate.ps1")) {
    Write-Host "ERROR: Virtual environment not found!" -ForegroundColor Red
    Write-Host "`nPlease create the virtual environment first:" -ForegroundColor Yellow
    Write-Host "  python -m venv venv" -ForegroundColor White
    Write-Host "  .\venv\Scripts\Activate.ps1" -ForegroundColor White
    Write-Host "  pip install -r requirements.txt`n" -ForegroundColor White
    exit 1
}

Write-Host "Activating virtual environment..." -ForegroundColor Green
& .\venv\Scripts\Activate.ps1

Write-Host "Starting PWA Installer Tool...`n" -ForegroundColor Green
python pwa_installer.py

# Keep window open if there was an error
if ($LASTEXITCODE -ne 0) {
    Write-Host "`nPress any key to exit..." -ForegroundColor Yellow
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}
