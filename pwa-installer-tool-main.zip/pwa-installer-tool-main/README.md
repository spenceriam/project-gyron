# PWA Installer Tool

A Windows desktop application that enables non-technical users to install Progressive Web Apps (PWAs) from zip files through an intuitive interface with automated icon generation and installation workflow management.

## Features

- **Simple Interface**: Drag-and-drop or click to select PWA zip files
- **Automatic Icon Generation**: Creates missing icons with professional blue-to-teal gradients
- **Browser Support**: Works with Edge, Chrome, Firefox, and Brave
- **Automated Server**: Handles local server setup automatically
- **Installation Detection**: Automatically detects when PWA is installed
- **Clean Cleanup**: Removes all temporary files automatically

## Installation

1. Download `PWA-Installer.exe` from the releases page
2. Run the executable (no installation needed)

## Usage

1. Run `PWA-Installer.exe`
2. Select your PWA zip file
3. Choose your browser
4. Click "Install PWA"
5. Click the Install button in your browser when it appears
6. Done!

## What Is a PWA?

A Progressive Web App (PWA) is a web application that can be installed on
your computer and run like a native application. PWAs can work offline (when designed to),
send notifications (if implemented), and appear in your Start Menu like regular programs.

## Troubleshooting

**Error: "This zip doesn't contain a valid PWA"**
- Ensure the zip contains a `manifest.json` file
- The `manifest.json` should be in the root of the zip or one folder deep

**Error: "Cannot start server"**
- Close other applications that might be using ports `8000-8009`
- Try restarting the application

**Error: "Browser not found"**
- Install one of the supported browsers
- Select a different browser from the dropdown

**Installation timeout**
- If the timeout occurs but you clicked Install in the browser, the PWA likely installed anyway
- Check your Start Menu for the application

## Security Notes

This application:
- Only runs a temporary local server (`localhost`) during installation
- Does not send any data over the internet
- Does not collect or store any personal information
- Automatically cleans up temporary files after installation

## Recent Internal Changes (Development)

- Added detailed service worker logging and error handling for shell page caching
- Install button now visible immediately (disabled until `beforeinstallprompt`); timeout fallback enables manual address bar install hint
- Renamed end-user guide from `README.txt` to `USER_GUIDE.txt` to avoid confusion with repository README
- Removed obsolete `IMPLEMENTATION_SUMMARY.md` (superseded by `AGENTS.md`)

## Requirements

- Windows 10 (1809+) or Windows 11
- One of: Microsoft Edge, Google Chrome, Mozilla Firefox, or Brave

## For Developers

### Setup

```bash
# Create virtual environment
python -m venv venv
venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### Running from Source

```bash
python pwa_installer.py
```

### Building Executable

```bash
python build.py
```

The executable will be created in `dist/PWA-Installer.exe`.

## Project Structure

```
pwa-installer-tool/
├── pwa_installer.py      # Main entry point
├── gui/                  # GUI components
│   ├── main_window.py   # Main application window
│   └── __init__.py
├── core/                # Core functionality
│   ├── processor.py     # PWA processing
│   ├── icon_generator.py # Icon creation
│   ├── server_manager.py # HTTP server
│   ├── browser_launcher.py # Browser control
│   └── __init__.py
├── utils/               # Utilities
│   ├── exceptions.py    # Custom exceptions
│   └── __init__.py
├── docs/               # Documentation
│   ├── requirements.md
│   ├── design.md
│   └── tasks.md
├── build.py           # Build script
├── requirements.txt   # Python dependencies
└── README.md         # This file
```

## Documentation

- [Requirements](docs/requirements.md) - Full requirements specification
- [Design](docs/design.md) - Technical design document
- [Tasks](docs/tasks.md) - Development task breakdown
- [AGENTS.md](AGENTS.md) - AI agent project memory

## Version

Current version: **0.5.0**

See [AGENTS.md](AGENTS.md) for version bumping protocol and approval workflow.

## License

MIT License - See LICENSE file for details

## Contributing

This is a personal project, but suggestions and bug reports are welcome via GitHub issues.

## Support

For issues or questions, please open an issue on GitHub.
