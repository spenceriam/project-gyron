"""Quick test to verify manifest rewriting logic"""
import sys
import os

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.server_manager import PWAServerManager

print("\n" + "="*60)
print("MANIFEST REWRITING TEST")
print("="*60)

# Use the extracted PWA directory (you'll need to provide actual path)
test_dir = input("\nEnter path to extracted PWA directory: ").strip().strip('"')

if not os.path.exists(test_dir):
    print(f"ERROR: Directory not found: {test_dir}")
    sys.exit(1)

print(f"\nTesting with: {test_dir}")

# Create server manager (this runs discovery)
manager = PWAServerManager(test_dir)

print(f"\n--- Discovery Results ---")
print(f"Remote Base: {manager.remote_base}")
print(f"Relative Start: {manager.manifest_relative_start}")

# Read original manifest
manifest_path = os.path.join(test_dir, 'manifest.json')
if os.path.exists(manifest_path):
    import json
    with open(manifest_path, 'r') as f:
        manifest = json.load(f)
    
    original_start = manifest.get('start_url')
    print(f"\n--- Original Manifest ---")
    print(f"start_url: {original_start}")
    
    # Simulate rewrite
    if manager.remote_base:
        relative_start = manager.manifest_relative_start or ''
        if relative_start.startswith('./'):
            relative_start = relative_start[1:]
        
        if relative_start:
            if relative_start.startswith('/'):
                target_url = manager.remote_base + relative_start
            else:
                target_url = manager.remote_base + '/' + relative_start
        else:
            target_url = manager.remote_base
        
        print(f"\n--- Rewritten Manifest ---")
        print(f"start_url: {target_url}")
        print(f"scope: {manager.remote_base}/")
        
        print(f"\n✓ Manifest rewrite would succeed")
    else:
        print(f"\n✗ ERROR: No remote base discovered!")
        print(f"   Cannot rewrite manifest without remote URL")
else:
    print(f"\nERROR: manifest.json not found at {manifest_path}")

print("\n" + "="*60)
