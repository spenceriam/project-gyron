"""Main GUI window for PWA Installer Tool"""

import os
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import threading
from typing import Optional
try:
    from tkinterdnd2 import TkinterDnD, DND_FILES
    DRAG_DROP_AVAILABLE = True
except ImportError:
    DRAG_DROP_AVAILABLE = False
from core.processor import PWAProcessor
from core.icon_generator import IconGenerator
from core.server_manager import PWAServerManager
from core.browser_launcher import BrowserLauncher
from utils.exceptions import PWAInstallerError


class PWAInstallerGUI:
    """Main application window"""
    
    def __init__(self):
        # Use TkinterDnD if available for drag-and-drop support
        if DRAG_DROP_AVAILABLE:
            self.root = TkinterDnD.Tk()
        else:
            self.root = tk.Tk()
        self.root.title("PWA Installer Tool")
        # Slightly increased height to ensure status bar is visible on high DPI / scaling
        self.root.geometry("520x440")
        self.root.resizable(False, False)
        
        # State variables
        self.current_zip_path: Optional[str] = None
        self.processor = PWAProcessor()
        self.server_manager = None
        self.browser_launcher = BrowserLauncher()
        
        self._create_widgets()
        self._populate_browsers()
        
        # Handle window close
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
    
    def _populate_browsers(self):
        """Populate browser dropdown with detected browsers"""
        browsers = self.browser_launcher.get_browser_names()
        if browsers:
            self.browser_dropdown['values'] = browsers
            default = self.browser_launcher.get_default_browser()
            if default:
                self.browser_var.set(default)
        else:
            self.browser_dropdown['values'] = []
            self.show_error("No supported browsers found. Please install Edge, Chrome, Firefox, or Brave.")
    
    def _create_widgets(self):
        """Create all GUI widgets"""
        # Content frame to allow status bar to stick to bottom cleanly
        self.content_frame = tk.Frame(self.root)
        self.content_frame.pack(fill=tk.BOTH, expand=True)

        # Drop zone / file selector
        self.drop_zone = tk.Frame(
            self.content_frame,
            width=450,
            height=150,
            relief=tk.RIDGE,
            bg="#f0f0f0",
            borderwidth=2
        )
        self.drop_zone.pack(pady=20, padx=25)
        self.drop_zone.pack_propagate(False)
        
        # Drop zone label
        self.drop_zone_label = tk.Label(
            self.drop_zone,
            text="Click to select PWA zip file",
            font=("Segoe UI", 12),
            bg="#f0f0f0",
            fg="#666666",
            cursor="hand2"
        )
        self.drop_zone_label.place(relx=0.5, rely=0.5, anchor=tk.CENTER)
        self.drop_zone_label.bind("<Button-1>", lambda e: self.browse_file())
        
        # Make entire drop zone clickable
        self.drop_zone.bind("<Button-1>", lambda e: self.browse_file())
        
        # Enable drag-and-drop if available
        if DRAG_DROP_AVAILABLE:
            self.drop_zone.drop_target_register(DND_FILES)
            self.drop_zone.dnd_bind('<<Drop>>', self.on_drop)
            self.drop_zone_label.drop_target_register(DND_FILES)
            self.drop_zone_label.dnd_bind('<<Drop>>', self.on_drop)
            self.drop_zone_label.config(text="Drag & drop PWA zip file or click to select")
        
        # App name label
        self.app_name_label = tk.Label(
            self.content_frame,
            text="App Name: (not loaded)",
            font=("Segoe UI", 11),
            fg="#333333"
        )
        self.app_name_label.pack(pady=10)
        
        # Browser selector frame
        browser_frame = tk.Frame(self.content_frame)
        browser_frame.pack(pady=10)
        
        tk.Label(
            browser_frame,
            text="Browser:",
            font=("Segoe UI", 10)
        ).pack(side=tk.LEFT, padx=(0, 5))
        
        self.browser_var = tk.StringVar()
        self.browser_dropdown = ttk.Combobox(
            browser_frame,
            textvariable=self.browser_var,
            state="readonly",
            width=20,
            font=("Segoe UI", 10)
        )

        # Base URL override input
        # Removed remote base URL override per user request. Landing page logic now auto-discovers remote domain.
        self.browser_dropdown.pack(side=tk.LEFT, padx=5)
        
        # Install button
        self.install_button = tk.Button(
            self.content_frame,
            text="Install PWA",
            width=30,
            height=2,
            state=tk.DISABLED,
            command=self.on_install_clicked,
            font=("Segoe UI", 11, "bold"),
            bg="#0078D4",
            fg="white",
            cursor="hand2"
        )
        self.install_button.pack(pady=20)

        # Cancel button (hidden until install in progress)
        self.cancel_button = tk.Button(
            self.content_frame,
            text="Cancel",
            width=30,
            height=1,
            state=tk.DISABLED,
            command=self.on_cancel_clicked,
            font=("Segoe UI", 9),
            bg="#d32f2f",
            fg="white"
        )
        self.cancel_button.pack(pady=(0,8))
        self.cancel_button.pack_forget()

        # Regenerate icons button
        self.regen_button = tk.Button(
            self.content_frame,
            text="Force Regenerate Icons",
            width=30,
            height=1,
            state=tk.DISABLED,
            command=self.on_regenerate_icons,
            font=("Segoe UI", 9),
            bg="#555555",
            fg="white"
        )
        self.regen_button.pack(pady=(0,10))
        
        # Bottom bar frame for status and version
        bottom_frame = tk.Frame(self.root)
        bottom_frame.pack(side=tk.BOTTOM, fill=tk.X, padx=12, pady=(4, 8))
        
        # Version label (bottom-left, ghost text)
        self.version_label = tk.Label(
            bottom_frame,
            text="v0.5.0",
            font=("Segoe UI", 8),
            fg="#cccccc",
            anchor="w"
        )
        self.version_label.pack(side=tk.LEFT)
        
        # Status label (bottom-right area)
        self.status_label = tk.Label(
            bottom_frame,
            text="Status: Ready",
            font=("Segoe UI", 9),
            fg="gray",
            anchor="w"
        )
        self.status_label.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(15, 0))
    
    def on_drop(self, event):
        """Handle drag-and-drop file event"""
        # tkinterdnd2 returns file path with {} wrapping on Windows
        file_path = event.data.strip()
        # Remove curly braces if present
        if file_path.startswith('{') and file_path.endswith('}'):
            file_path = file_path[1:-1]
        # Handle multiple files - take first one
        if ' ' in file_path and not os.path.exists(file_path):
            file_path = file_path.split()[0]
            if file_path.startswith('{'):
                file_path = file_path[1:]
        if file_path and os.path.exists(file_path):
            self.on_file_selected(file_path)
        return event.action
    
    def browse_file(self):
        """Open file browser to select zip file"""
        file_path = filedialog.askopenfilename(
            title="Select PWA Zip File",
            filetypes=[("Zip files", "*.zip"), ("All files", "*.*")]
        )
        
        if file_path:
            self.on_file_selected(file_path)
    
    def on_file_selected(self, zip_path: str):
        """Handle file selection and PWA processing"""
        self.current_zip_path = zip_path
        filename = os.path.basename(zip_path)
        self.drop_zone_label.config(text=f"Selected: {filename}")
        
        try:
            # Update status
            self.update_status("Extracting zip...")
            self.root.update()
            
            # Extract and validate
            extracted_path = self.processor.extract_zip(zip_path)
            self.processor.validate_manifest(extracted_path)
            pwa_name = self.processor.get_pwa_name()
            
            # Generate missing icons
            self.update_status("Generating icons...")
            self.root.update()
            icon_gen = IconGenerator(
                self.processor.manifest,
                self.processor.extracted_path
            )
            icon_gen.generate_missing_icons()
            
            # Update GUI
            self.app_name_label.config(text=f"App Name: {pwa_name}")
            self.install_button.config(
                text=f"Install {pwa_name}",
                state=tk.NORMAL
            )
            self.regen_button.config(state=tk.NORMAL)
            self.update_status("Ready to install")
            
        except PWAInstallerError as e:
            self.show_error(e.message)
            self.processor.cleanup()
            self.reset_gui()
        except Exception as e:
            self.show_error(f"Error processing PWA: {str(e)}")
            self.processor.cleanup()
            self.reset_gui()
    
    def on_install_clicked(self):
        """Start local server (if not running) and open static install landing page."""
        try:
            if not self.processor or not self.processor.extracted_path:
                self.show_error("No PWA loaded.")
                return
            browser = self.browser_var.get()
            if not browser:
                self.show_error("Please select a browser")
                return
            pwa_name = self.processor.get_pwa_name() if self.processor.pwa_name else "PWA"
            # If server already running, just open another tab to landing page
            if self.server_manager:
                port = self.server_manager.port
                url = f"http://localhost:{port}/__install__"
                self.browser_launcher.launch(browser, url)
                self.update_status("Opened landing page again")
                return
            # Start new server
            self.update_status("Starting server...")
            self.server_manager = PWAServerManager(self.processor.extracted_path)
            port = self.server_manager.start()
            self.update_status("Opening browser...")
            url = f"http://localhost:{port}/__install__"
            self.browser_launcher.launch(browser, url)
            self.install_button.config(text="Open Landing Page", state=tk.NORMAL)
            self.cancel_button.config(state=tk.NORMAL)
            self.cancel_button.pack()
            self.update_status("Landing page opened - install from browser; app will launch shell when opened from Start.")
        except Exception as e:
            self.show_error(f"Failed to start server: {e}")
            if self.server_manager:
                try:
                    self.server_manager.stop()
                except:
                    pass
                self.server_manager = None
    
    # Legacy installation completion & retry functions removed (no wait/timeout logic).
    
    def cleanup_after_install(self):
        """Cleanup server and extracted files (manual invocation)."""
        if self.server_manager:
            try:
                self.server_manager.stop()
            except:
                pass
            self.server_manager = None
        if self.processor:
            try:
                self.processor.cleanup()
            except:
                pass
        self.reset_gui()

    def handle_install_failure(self, message: str):
        """Simplified failure handler."""
        self.show_error(message)
        if self.server_manager:
            try:
                self.server_manager.stop()
            except:
                pass
            self.server_manager = None
        # Keep extracted files so user can retry without re-selecting zip

    def prepare_retry(self, pwa_name: str):
        """Legacy retry removed; repurpose to just enable button again."""
        self.install_button.config(text="Open Landing Page", state=tk.NORMAL)
        if not self.browser_var.get():
            default = self.browser_launcher.get_default_browser()
            if default:
                self.browser_var.set(default)
    
    def reset_gui(self):
        """Reset GUI to initial state"""
        self.app_name_label.config(text="App Name: (not loaded)")
        self.install_button.config(text="Install PWA", state=tk.DISABLED)
        self.drop_zone_label.config(text="Click to select PWA zip file")
        self.regen_button.config(state=tk.DISABLED)
        self.current_zip_path = None
        self.update_status("Ready")
        try:
            self.cancel_button.pack_forget()
        except Exception:
            pass

    def on_regenerate_icons(self):
        """Force regenerate icons even if they exist."""
        try:
            if not self.processor.manifest:
                self.show_error("No manifest loaded.")
                return
            icon_gen = IconGenerator(self.processor.manifest, self.processor.extracted_path)
            icon_gen.regenerate_all_icons()
            self.update_status("Icons regenerated")
        except Exception as e:
            self.show_error(f"Failed to regenerate icons: {e}")
    
    def update_status(self, message: str):
        """Update status label"""
        self.status_label.config(text=f"Status: {message}")
        self.root.update_idletasks()
    
    def show_error(self, message: str):
        """Show error dialog"""
        messagebox.showerror("Error", message)
    
    def show_success(self, message: str):
        """Show success dialog"""
        messagebox.showinfo("Success", message)
    
    def on_closing(self):
        """Handle window close: force immediate exit without waiting for cleanup."""
        # Set flag to prevent any further operations
        if self.server_manager:
            self.server_manager.stop()
        
        # Force immediate exit - daemon threads will be killed by Python runtime
        self.root.quit()
        self.root.destroy()
    
    def run(self):
        """Start the GUI event loop"""
        self.root.mainloop()

    def on_cancel_clicked(self):
        """Stop server and cleanup extracted files immediately."""
        if self.server_manager:
            try:
                self.server_manager.stop()
            except:
                pass
            self.server_manager = None
        if self.processor:
            try:
                self.processor.cleanup()
            except:
                pass
        self.reset_gui()
        self.update_status("Cancelled and cleaned up")
        try:
            self.cancel_button.pack_forget()
        except Exception:
            pass
