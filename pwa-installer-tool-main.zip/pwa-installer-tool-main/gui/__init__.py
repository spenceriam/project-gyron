"""GUI package for PWA Installer Tool"""
