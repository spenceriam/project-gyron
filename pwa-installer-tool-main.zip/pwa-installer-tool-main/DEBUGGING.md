# DEBUGGING STEPS - PWA INSTALLER

## CRITICAL: Browser Caching Issue

The browser CACHES the PWA manifest after installation. If you installed the PWA before the latest code changes, you MUST:

### Step 1: Completely Uninstall Old PWA
1. Open Windows Settings
2. Go to Apps > Installed Apps
3. Find "Gemini Enterprise" (or your PWA name)
4. Click three dots → Uninstall
5. Confirm uninstall

### Step 2: Clear Browser Cache
**Microsoft Edge:**
1. Open Edge
2. Press Ctrl+Shift+Delete
3. Select "All time" for time range
4. Check: Cached images and files
5. Click "Clear now"
6. **Close ALL Edge windows completely**

**Chrome:**
1. Open Chrome
2. Press Ctrl+Shift+Delete
3. Select "All time"
4. Check: Cached images and files
5. Click "Clear data"
6. **Close ALL Chrome windows completely**

### Step 3: Restart Browser
1. Completely close the browser (check Task Manager if needed)
2. Wait 5 seconds
3. Reopen browser

### Step 4: Run Fresh Installation
1. Open PowerShell in project directory
2. Run: `.\run.ps1`
3. Drag/drop the PWA zip file
4. Click "Open Landing Page"
5. **Watch the PowerShell window for diagnostic output:**
   - Look for: `[Server] ========== MANIFEST REQUEST RECEIVED ==========`
   - Look for: `[Server] ✓ MANIFEST REWRITTEN: ... -> https://...`
6. Install the PWA from browser
7. Close the installer tool
8. Open the installed PWA from Start menu

### Step 5: Verify
- The installed PWA should now open directly to the remote URL
- If you still see the purple landing page, the browser is still using cached data

## Test Without Installing (Optional)
Run the diagnostic test:
```powershell
python test_manifest.py
```
Enter the path to your extracted PWA folder when prompted.
This will show you what URL the manifest would be rewritten to.

## If Still Failing
Check the PowerShell output for these lines:
```
[Server] Remote discovery: base=https://... relative_start=...
[Server] ========== MANIFEST REQUEST RECEIVED ==========
[Server] DEBUG: remote_base=https://..., relative_start=...
[Server] ✓ MANIFEST REWRITTEN: ... -> https://...
```

If you DON'T see these lines, the manifest is not being requested or rewritten.
If you see `✗ ERROR: No remote base discovered`, the tool cannot find the remote URL in your PWA files.
