# PWA Installer Tool - Task Breakdown (BMAD)

## Overview
This document breaks down the PWA Installer Tool development into discrete, measurable tasks following the BMAD (Build-Measure-Analyze-Decide) methodology.

## Task Dependency Map

```
T1 (Setup) → T2 (GUI Foundation)
                ↓
T3 (Zip Processing) → T4 (Icon Generation)
                ↓              ↓
            T5 (Server Manager)
                ↓
        T6 (Browser Integration)
                ↓
            T7 (Integration)
                ↓
            T8 (Packaging)
```

---

## Task 1: Project Setup and Structure

### Build
**Objective:** Establish project structure, dependencies, and development environment

**Deliverables:**
- Project directory structure created
- Python 3.8+ virtual environment configured
- Dependencies installed (Pillow, PyInstaller)
- Git repository initialized (optional)
- Basic entry point file (`pwa_installer.py`) created

**Implementation Steps:**
```bash
# Create project structure
mkdir pwa-installer
cd pwa-installer
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Create directories
mkdir -p gui core utils assets

# Create __init__.py files
touch gui/__init__.py core/__init__.py utils/__init__.py

# Install dependencies
pip install Pillow PyInstaller

# Create requirements.txt
pip freeze > requirements.txt
```

**Files to Create:**
- `pwa_installer.py` (main entry point)
- `gui/__init__.py`, `gui/main_window.py`, `gui/widgets.py`
- `core/__init__.py`, `core/processor.py`, `core/icon_generator.py`
- `core/server_manager.py`, `core/browser_launcher.py`
- `utils/__init__.py`, `utils/exceptions.py`, `utils/validators.py`

### Measure
**Success Criteria:**
- [ ] Virtual environment activates successfully
- [ ] All directories exist and are properly structured
- [ ] `import PIL` works without errors
- [ ] `import tkinter` works without errors
- [ ] Basic entry point file runs without import errors

**Validation Commands:**
```bash
python -c "import PIL; print('PIL version:', PIL.__version__)"
python -c "import tkinter; print('tkinter available')"
python pwa_installer.py  # Should run without import errors
```

### Analyze
**Performance Targets:**
- Setup completes in < 5 minutes
- All imports resolve without errors
- Project structure matches design document

**Quality Checks:**
- Verify Python version is 3.8+
- Confirm all required directories exist
- Check that __init__.py files are present

### Decide
**Decision Criteria:**
- If imports fail: Install missing system dependencies
- If Python version < 3.8: Upgrade Python or document limitation
- If structure incomplete: Complete missing directories before proceeding

**Next Steps:**
- ✅ All criteria met → Proceed to Task 2
- ❌ Import errors → Fix dependencies, retest
- ❌ Structure issues → Complete structure, retest

---

## Task 2: GUI Foundation (Tkinter Window)

### Build
**Objective:** Create basic GUI window with drag-and-drop zone, browser selector, and install button

**Deliverables:**
- Main window with 500x400px fixed size
- Drag-and-drop zone widget
- Browser selection dropdown
- Install button (initially disabled)
- Status label

**Implementation Steps:**

```python
# gui/main_window.py
import tkinter as tk
from tkinter import ttk
from tkinterdnd2 import DND_FILES, TkinterDnD

class PWAInstallerGUI:
    def __init__(self):
        self.root = TkinterDnD.Tk()
        self.root.title("PWA Installer Tool")
        self.root.geometry("500x400")
        self.root.resizable(False, False)
        
        self._create_widgets()
    
    def _create_widgets(self):
        # Drop zone
        self.drop_zone = tk.Label(
            self.root,
            text="Drag PWA zip file here\nor click to browse",
            width=50,
            height=10,
            relief=tk.RIDGE,
            bg="#f0f0f0"
        )
        self.drop_zone.pack(pady=20)
        self.drop_zone.drop_target_register(DND_FILES)
        self.drop_zone.dnd_bind('<<Drop>>', self.on_drop)
        
        # App name label
        self.app_name_label = tk.Label(
            self.root,
            text="App Name: (not loaded)",
            font=("Segoe UI", 12)
        )
        self.app_name_label.pack(pady=10)
        
        # Browser selector
        browser_frame = tk.Frame(self.root)
        browser_frame.pack(pady=10)
        
        tk.Label(browser_frame, text="Browser:").pack(side=tk.LEFT)
        self.browser_var = tk.StringVar()
        self.browser_dropdown = ttk.Combobox(
            browser_frame,
            textvariable=self.browser_var,
            state="readonly",
            width=20
        )
        self.browser_dropdown.pack(side=tk.LEFT, padx=5)
        
        # Install button
        self.install_button = tk.Button(
            self.root,
            text="Install PWA",
            width=30,
            height=2,
            state=tk.DISABLED,
            command=self.on_install_clicked
        )
        self.install_button.pack(pady=20)
        
        # Status label
        self.status_label = tk.Label(
            self.root,
            text="Status: Ready",
            font=("Segoe UI", 10),
            fg="gray"
        )
        self.status_label.pack(pady=10)
    
    def on_drop(self, event):
        # Placeholder for drop handling
        pass
    
    def on_install_clicked(self):
        # Placeholder for install handling
        pass
    
    def run(self):
        self.root.mainloop()
```

### Measure
**Success Criteria:**
- [ ] Window appears with correct dimensions (500x400)
- [ ] All widgets visible and properly positioned
- [ ] Drop zone accepts file drops (visual feedback)
- [ ] Browser dropdown displays (empty for now)
- [ ] Install button is disabled initially
- [ ] Window closes cleanly without errors

**Visual Validation:**
- Window centered on screen
- Font sizes readable
- Widgets properly aligned
- No overlapping elements

### Analyze
**Performance Targets:**
- Window opens in < 1 second
- UI remains responsive during testing
- No memory leaks on window close

**Quality Checks:**
- Window resizing disabled correctly
- Drop zone shows hover effect
- Fonts render correctly on Windows

### Decide
**Decision Criteria:**
- If TkinterDnD2 unavailable: Fall back to file dialog button
- If fonts not rendering: Use fallback system fonts
- If layout issues: Adjust padding/spacing

**Next Steps:**
- ✅ GUI renders correctly → Proceed to Task 3
- ❌ Layout issues → Adjust widget parameters
- ❌ Drop zone not working → Implement file dialog fallback

---

## Task 3: Zip Processing and Validation

### Build
**Objective:** Implement zip extraction, manifest validation, and PWA name extraction

**Deliverables:**
- `PWAProcessor` class with extraction logic
- Manifest.json validation
- Custom exception classes
- Temporary directory management

**Implementation Steps:**

```python
# utils/exceptions.py
class PWAInstallerError(Exception):
    """Base exception with user-friendly messages"""
    pass

class ManifestNotFoundError(PWAInstallerError):
    def __init__(self):
        self.message = "This zip doesn't contain a valid PWA. Missing manifest.json file."
        super().__init__(self.message)

class ManifestInvalidError(PWAInstallerError):
    def __init__(self):
        self.message = "The PWA's manifest.json file is corrupted or invalid."
        super().__init__(self.message)

# core/processor.py
import os
import json
import zipfile
import tempfile
import shutil
from urllib.parse import urlparse
from utils.exceptions import ManifestNotFoundError, ManifestInvalidError

class PWAProcessor:
    def __init__(self):
        self.temp_dir = None
        self.manifest = None
        self.pwa_name = None
        self.extracted_path = None
    
    def extract_zip(self, zip_path: str) -> str:
        """Extract zip to temporary directory"""
        self.temp_dir = tempfile.mkdtemp(prefix="pwa_installer_")
        
        try:
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                # Security: validate paths
                for member in zip_ref.namelist():
                    if member.startswith('/') or '..' in member:
                        raise ValueError("Zip contains invalid paths")
                
                zip_ref.extractall(self.temp_dir)
            
            self.extracted_path = self.temp_dir
            return self.temp_dir
            
        except Exception as e:
            self.cleanup()
            raise
    
    def validate_manifest(self, extracted_path: str) -> dict:
        """Find and validate manifest.json"""
        # Check root directory
        manifest_path = os.path.join(extracted_path, 'manifest.json')
        
        if not os.path.exists(manifest_path):
            # Check one level deep
            for item in os.listdir(extracted_path):
                item_path = os.path.join(extracted_path, item)
                if os.path.isdir(item_path):
                    manifest_path = os.path.join(item_path, 'manifest.json')
                    if os.path.exists(manifest_path):
                        self.extracted_path = item_path
                        break
            else:
                raise ManifestNotFoundError()
        
        # Parse JSON
        try:
            with open(manifest_path, 'r', encoding='utf-8') as f:
                self.manifest = json.load(f)
            return self.manifest
        except json.JSONDecodeError:
            raise ManifestInvalidError()
    
    def get_pwa_name(self) -> str:
        """Extract PWA name from manifest"""
        if not self.manifest:
            return "Unknown PWA"
        
        # Priority: name, short_name, start_url domain
        if 'name' in self.manifest:
            self.pwa_name = self.manifest['name']
        elif 'short_name' in self.manifest:
            self.pwa_name = self.manifest['short_name']
        elif 'start_url' in self.manifest:
            parsed = urlparse(self.manifest['start_url'])
            self.pwa_name = parsed.netloc or "PWA"
        else:
            self.pwa_name = "PWA"
        
        return self.pwa_name
    
    def cleanup(self):
        """Remove temporary files"""
        if self.temp_dir and os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
            self.temp_dir = None
```

### Measure
**Success Criteria:**
- [ ] Valid zip extracts successfully
- [ ] Manifest.json found and parsed correctly
- [ ] PWA name extracted from manifest
- [ ] Invalid zip raises ManifestNotFoundError
- [ ] Corrupted JSON raises ManifestInvalidError
- [ ] Temporary directory cleaned up on error

**Test Cases:**
```python
# Test valid PWA
processor = PWAProcessor()
path = processor.extract_zip("valid_pwa.zip")
manifest = processor.validate_manifest(path)
name = processor.get_pwa_name()
assert name == "Expected Name"

# Test missing manifest
try:
    processor.extract_zip("no_manifest.zip")
    processor.validate_manifest(path)
    assert False, "Should have raised ManifestNotFoundError"
except ManifestNotFoundError:
    pass

# Test cleanup
processor.cleanup()
assert not os.path.exists(processor.temp_dir)
```

### Analyze
**Performance Targets:**
- Extract 5MB zip in < 2 seconds
- Manifest parsing in < 100ms
- Cleanup completes in < 500ms

**Quality Checks:**
- No temporary files left after cleanup
- Path traversal attacks prevented
- Unicode characters in manifest handled correctly

### Decide
**Decision Criteria:**
- If extraction slow: Consider streaming extraction
- If manifest parsing fails: Add more detailed error messages
- If cleanup fails: Log warning, continue (OS will cleanup temp eventually)

**Next Steps:**
- ✅ All tests pass → Proceed to Task 4
- ❌ Extraction fails → Debug zipfile handling
- ❌ Cleanup incomplete → Improve error handling

---

## Task 4: Icon Generation

### Build
**Objective:** Generate missing PWA icons with blue-to-teal gradient and white letter

**Deliverables:**
- `IconGenerator` class
- Gradient generation algorithm
- Text overlay functionality
- Icon size parsing and creation

**Implementation Steps:**

```python
# core/icon_generator.py
import os
from PIL import Image, ImageDraw, ImageFont
from urllib.parse import urlparse

class IconGenerator:
    GRADIENT_START = (0, 0, 255)      # Blue
    GRADIENT_END = (0, 128, 128)      # Teal
    TEXT_COLOR = (255, 255, 255)       # White
    
    def __init__(self, manifest: dict, base_path: str):
        self.manifest = manifest
        self.base_path = base_path
        self.letter = self._extract_letter()
    
    def _extract_letter(self) -> str:
        """Get first letter from name or start_url"""
        # Priority: name, short_name, start_url domain
        name = None
        if 'name' in self.manifest:
            name = self.manifest['name']
        elif 'short_name' in self.manifest:
            name = self.manifest['short_name']
        elif 'start_url' in self.manifest:
            parsed = urlparse(self.manifest['start_url'])
            domain = parsed.netloc or parsed.path
            name = domain.split('.')[0] if domain else 'P'
        
        return (name[0] if name else 'P').upper()
    
    def generate_missing_icons(self):
        """Create all missing icons from manifest"""
        icons = self.manifest.get('icons', [])
        
        for icon_entry in icons:
            icon_path = os.path.join(self.base_path, icon_entry['src'])
            
            if not os.path.exists(icon_path):
                size = self._parse_size(icon_entry.get('sizes', '512x512'))
                self._generate_icon(icon_path, size)
    
    def _parse_size(self, sizes_str: str) -> int:
        """Parse size string like '512x512' to integer"""
        # Take first size if multiple
        size_parts = sizes_str.split()[0].split('x')
        return int(size_parts[0])
    
    def _generate_icon(self, icon_path: str, size: int):
        """Generate single icon with gradient and text"""
        # Create gradient
        img = self._create_gradient(size)
        
        # Add text
        img = self._add_text(img, self.letter, size)
        
        # Save icon
        os.makedirs(os.path.dirname(icon_path), exist_ok=True)
        img.save(icon_path, 'PNG')
    
    def _create_gradient(self, size: int) -> Image.Image:
        """Create vertical blue-to-teal gradient"""
        img = Image.new('RGB', (size, size))
        draw = ImageDraw.Draw(img)
        
        for y in range(size):
            ratio = y / size
            r = int(self.GRADIENT_START[0] + ratio * (self.GRADIENT_END[0] - self.GRADIENT_START[0]))
            g = int(self.GRADIENT_START[1] + ratio * (self.GRADIENT_END[1] - self.GRADIENT_START[1]))
            b = int(self.GRADIENT_START[2] + ratio * (self.GRADIENT_END[2] - self.GRADIENT_START[2]))
            draw.line([(0, y), (size, y)], fill=(r, g, b))
        
        return img
    
    def _add_text(self, img: Image.Image, letter: str, size: int) -> Image.Image:
        """Add centered white letter to image"""
        draw = ImageDraw.Draw(img)
        font_size = int(size * 0.6)
        
        try:
            font = ImageFont.truetype("arialbd.ttf", font_size)
        except:
            try:
                font = ImageFont.truetype("arial.ttf", font_size)
            except:
                font = ImageFont.load_default()
        
        # Get text size
        bbox = draw.textbbox((0, 0), letter, font=font)
        text_width = bbox[2] - bbox[0]
        text_height = bbox[3] - bbox[1]
        
        # Calculate center position
        x = (size - text_width) // 2
        y = (size - text_height) // 2
        
        # Draw text
        draw.text((x, y), letter, fill=self.TEXT_COLOR, font=font)
        
        return img
```

### Measure
**Success Criteria:**
- [ ] 512x512 icon generates with correct gradient
- [ ] Letter is white, centered, and properly sized
- [ ] Multiple icon sizes generated correctly
- [ ] Missing directories created automatically
- [ ] Existing icons not overwritten
- [ ] Generation completes in < 1 second per icon

**Test Cases:**
```python
# Test icon generation
manifest = {
    'name': 'Test App',
    'icons': [
        {'src': 'icons/icon-192.png', 'sizes': '192x192'},
        {'src': 'icons/icon-512.png', 'sizes': '512x512'}
    ]
}

generator = IconGenerator(manifest, '/tmp/test')
generator.generate_missing_icons()

# Verify icons exist
assert os.path.exists('/tmp/test/icons/icon-192.png')
assert os.path.exists('/tmp/test/icons/icon-512.png')

# Verify image properties
img = Image.open('/tmp/test/icons/icon-512.png')
assert img.size == (512, 512)
assert img.mode == 'RGB'
```

### Analyze
**Performance Targets:**
- 192x192 icon: < 0.5 seconds
- 512x512 icon: < 1 second
- Gradient generation: < 100ms per icon

**Quality Checks:**
- Gradient smooth without banding
- Text clearly readable
- Colors match specification (Blue #0000FF, Teal #008080)
- PNG saved with correct format

### Decide
**Decision Criteria:**
- If font loading fails: Use PIL default font (acceptable for MVP)
- If generation slow: Consider caching gradient template
- If text off-center: Adjust bbox calculation

**Next Steps:**
- ✅ Icons generate correctly → Proceed to Task 5
- ❌ Gradient not smooth → Increase interpolation precision
- ❌ Text positioning wrong → Debug bbox calculation

---

## Task 5: HTTP Server Manager

### Build
**Objective:** Implement local HTTP server with port finding and installation detection

**Deliverables:**
- `PWAServerManager` class
- Port availability detection
- Install event detection via POST endpoint
- Server threading for GUI responsiveness

**Implementation Steps:**

```python
# core/server_manager.py
import os
import socket
import threading
import http.server
from typing import Optional

class InstallDetectionHandler(http.server.SimpleHTTPRequestHandler):
    """Custom HTTP handler with install detection"""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=kwargs.pop('directory'), **kwargs)
    
    def do_POST(self):
        """Handle installation completion signal"""
        if self.path == '/install-complete':
            self.server.install_detected.set()
            self.send_response(200)
            self.send_header('Content-Type', 'text/plain')
            self.end_headers()
            self.wfile.write(b'OK')
            return
        
        self.send_error(404)
    
    def do_GET(self):
        """Serve files with injected detection script"""
        if self.path in ['/', '/index.html']:
            # Inject detection script
            index_path = os.path.join(self.directory, 'index.html')
            if os.path.exists(index_path):
                with open(index_path, 'r', encoding='utf-8') as f:
                    html = f.read()
                
                # Inject script
                injection = """
<script>
window.addEventListener('appinstalled', () => {
    fetch('/install-complete', {method: 'POST'});
});
</script>
"""
                if '</body>' in html:
                    html = html.replace('</body>', injection + '</body>')
                elif '</head>' in html:
                    html = html.replace('</head>', injection + '</head>')
                else:
                    html += injection
                
                # Send modified HTML
                self.send_response(200)
                self.send_header('Content-Type', 'text/html')
                self.send_header('Content-Length', len(html.encode()))
                self.end_headers()
                self.wfile.write(html.encode())
                return
        
        # Serve other files normally
        super().do_GET()
    
    def log_message(self, format, *args):
        # Suppress server logs
        pass

class PWAServerManager:
    """Manages HTTP server lifecycle"""
    
    PORT_RANGE = range(8000, 8010)
    TIMEOUT_SECONDS = 120
    
    def __init__(self, pwa_directory: str):
        self.directory = pwa_directory
        self.port = None
        self.server = None
        self.server_thread = None
        self.install_detected = threading.Event()
    
    def start(self) -> int:
        """Start server on available port"""
        self.port = self._find_available_port()
        
        # Create server
        handler = lambda *args, **kwargs: InstallDetectionHandler(
            *args, directory=self.directory, **kwargs
        )
        self.server = http.server.HTTPServer(('localhost', self.port), handler)
        self.server.install_detected = self.install_detected
        
        # Start in thread
        self.server_thread = threading.Thread(target=self.server.serve_forever)
        self.server_thread.daemon = True
        self.server_thread.start()
        
        return self.port
    
    def _find_available_port(self) -> int:
        """Find first available port in range"""
        for port in self.PORT_RANGE:
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.bind(('localhost', port))
                    return port
            except OSError:
                continue
        
        raise Exception("No available ports in range 8000-8009")
    
    def wait_for_installation(self, timeout: Optional[int] = None) -> bool:
        """Wait for installation signal or timeout"""
        timeout = timeout or self.TIMEOUT_SECONDS
        return self.install_detected.wait(timeout)
    
    def stop(self):
        """Stop server and cleanup"""
        if self.server:
            self.server.shutdown()
            self.server = None
        
        if self.server_thread:
            self.server_thread.join(timeout=1)
            self.server_thread = None
```

### Measure
**Success Criteria:**
- [ ] Server starts on available port (8000-8009)
- [ ] Server serves static files correctly
- [ ] Injected JavaScript included in index.html
- [ ] POST to /install-complete triggers detection
- [ ] Server stops cleanly without hanging
- [ ] GUI remains responsive while server running

**Test Cases:**
```python
# Test server startup
manager = PWAServerManager('/tmp/test_pwa')
port = manager.start()
assert 8000 <= port < 8010

# Test file serving
import requests
response = requests.get(f'http://localhost:{port}/manifest.json')
assert response.status_code == 200

# Test install detection
requests.post(f'http://localhost:{port}/install-complete')
assert manager.install_detected.is_set()

# Test cleanup
manager.stop()
```

### Analyze
**Performance Targets:**
- Server starts in < 1 second
- Port detection completes in < 100ms
- File serving latency < 50ms
- Server stops in < 1 second

**Quality Checks:**
- No port conflicts
- Injected script syntax valid
- Thread cleanup complete
- No zombie processes

### Decide
**Decision Criteria:**
- If all ports busy: Show error, suggest closing apps
- If injection fails: Serve original HTML (user manual install)
- If thread won't stop: Force kill after timeout

**Next Steps:**
- ✅ Server works correctly → Proceed to Task 6
- ❌ Port issues → Expand port range
- ❌ Threading problems → Review thread lifecycle

---

## Task 6: Browser Detection and Launching

### Build
**Objective:** Detect installed browsers and launch with PWA URL

**Deliverables:**
- `BrowserLauncher` class
- Browser detection for Edge, Chrome, Firefox, Brave
- Browser launching with URL

**Implementation Steps:**

```python
# core/browser_launcher.py
import os
import subprocess
from typing import Dict, List

class BrowserLauncher:
    """Detect and launch browsers"""
    
    BROWSER_PATHS = {
        'Microsoft Edge': [
            r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
            r'C:\Program Files\Microsoft\Edge\Application\msedge.exe'
        ],
        'Google Chrome': [
            r'C:\Program Files\Google\Chrome\Application\chrome.exe',
            r'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe'
        ],
        'Mozilla Firefox': [
            r'C:\Program Files\Mozilla Firefox\firefox.exe',
            r'C:\Program Files (x86)\Mozilla Firefox\firefox.exe'
        ],
        'Brave': [
            r'C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe',
            r'C:\Program Files (x86)\BraveSoftware\Brave-Browser\Application\brave.exe'
        ]
    }
    
    def __init__(self):
        self.available_browsers = self._detect_browsers()
    
    def _detect_browsers(self) -> Dict[str, str]:
        """Detect installed browsers"""
        found = {}
        for name, paths in self.BROWSER_PATHS.items():
            for path in paths:
                if os.path.exists(path):
                    found[name] = path
                    break
        return found
    
    def get_browser_names(self) -> List[str]:
        """Get list of available browser names"""
        return list(self.available_browsers.keys())
    
    def get_default_browser(self) -> str:
        """Get default browser (prefer Edge)"""
        if 'Microsoft Edge' in self.available_browsers:
            return 'Microsoft Edge'
        elif self.available_browsers:
            return list(self.available_browsers.keys())[0]
        return None
    
    def launch(self, browser_name: str, url: str):
        """Launch browser with URL"""
        if browser_name not in self.available_browsers:
            raise ValueError(f"Browser '{browser_name}' not found")
        
        browser_path = self.available_browsers[browser_name]
        subprocess.Popen([browser_path, url])
```

### Measure
**Success Criteria:**
- [ ] Edge detected if installed
- [ ] Chrome detected if installed
- [ ] Firefox detected if installed
- [ ] Brave detected if installed
- [ ] Default browser selection prioritizes Edge
- [ ] Browser launches with correct URL
- [ ] Launch doesn't block GUI

**Test Cases:**
```python
# Test detection
launcher = BrowserLauncher()
browsers = launcher.get_browser_names()
assert len(browsers) > 0, "At least one browser should be detected"

# Test default
default = launcher.get_default_browser()
assert default in browsers

# Test launch (manual verification)
launcher.launch(default, 'http://localhost:8000')
# Verify: Browser opens with correct URL
```

### Analyze
**Performance Targets:**
- Browser detection: < 200ms
- Browser launch: < 2 seconds

**Quality Checks:**
- All installed browsers detected
- No false positives
- Launch doesn't throw errors

### Decide
**Decision Criteria:**
- If no browsers found: Show error, suggest installing browser
- If Edge not found: Default to Chrome, then Firefox, then Brave
- If launch fails: Show error with browser path

**Next Steps:**
- ✅ Browser detection works → Proceed to Task 7
- ❌ Detection incomplete → Add more path variations
- ❌ Launch fails → Debug subprocess call

---

## Task 7: Full Integration and GUI Wiring

### Build
**Objective:** Wire all components together in GUI with complete workflow

**Deliverables:**
- Complete `on_drop` handler
- Complete `on_install_clicked` handler
- Status updates and error handling
- Success/error message dialogs

**Implementation Steps:**

```python
# gui/main_window.py (additions)
import tkinter.messagebox as messagebox
from core.processor import PWAProcessor
from core.icon_generator import IconGenerator
from core.server_manager import PWAServerManager
from core.browser_launcher import BrowserLauncher
from utils.exceptions import PWAInstallerError

class PWAInstallerGUI:
    def __init__(self):
        # ... existing init code ...
        self.processor = PWAProcessor()
        self.server_manager = None
        self.browser_launcher = BrowserLauncher()
        self.current_zip_path = None
        
        # Populate browser dropdown
        browsers = self.browser_launcher.get_browser_names()
        self.browser_dropdown['values'] = browsers
        default = self.browser_launcher.get_default_browser()
        if default:
            self.browser_var.set(default)
    
    def on_drop(self, event):
        """Handle zip file drop"""
        # Get file path
        zip_path = event.data.strip('{}')
        
        if not zip_path.endswith('.zip'):
            self.show_error("Please drop a .zip file")
            return
        
        self.current_zip_path = zip_path
        
        try:
            # Update status
            self.update_status("Extracting zip...")
            
            # Extract and validate
            extracted_path = self.processor.extract_zip(zip_path)
            self.processor.validate_manifest(extracted_path)
            pwa_name = self.processor.get_pwa_name()
            
            # Generate icons
            self.update_status("Generating icons...")
            icon_gen = IconGenerator(
                self.processor.manifest,
                self.processor.extracted_path
            )
            icon_gen.generate_missing_icons()
            
            # Update GUI
            self.app_name_label.config(text=f"App Name: {pwa_name}")
            self.install_button.config(
                text=f"Install {pwa_name}",
                state=tk.NORMAL
            )
            self.update_status("Ready to install")
            
        except PWAInstallerError as e:
            self.show_error(e.message)
            self.processor.cleanup()
        except Exception as e:
            self.show_error(f"Error: {str(e)}")
            self.processor.cleanup()
    
    def on_install_clicked(self):
        """Handle install button click"""
        try:
            # Disable button
            self.install_button.config(state=tk.DISABLED)
            
            # Start server
            self.update_status("Starting server...")
            self.server_manager = PWAServerManager(
                self.processor.extracted_path
            )
            port = self.server_manager.start()
            
            # Launch browser
            self.update_status("Opening browser...")
            browser = self.browser_var.get()
            url = f"http://localhost:{port}"
            self.browser_launcher.launch(browser, url)
            
            # Show instructions
            self.update_status("Look for the Install button in your browser address bar")
            
            # Wait for installation in background thread
            def wait_and_complete():
                installed = self.server_manager.wait_for_installation()
                
                # Update GUI from main thread
                self.root.after(0, self.on_installation_complete, installed)
            
            threading.Thread(target=wait_and_complete, daemon=True).start()
            
        except Exception as e:
            self.show_error(f"Installation failed: {str(e)}")
            self.cleanup_after_install()
    
    def on_installation_complete(self, success: bool):
        """Handle installation completion"""
        if success:
            pwa_name = self.processor.get_pwa_name()
            messagebox.showinfo(
                "Installation Complete",
                f"✓ {pwa_name} installed!\n\nFind it in your Start Menu or Taskbar."
            )
        else:
            messagebox.showwarning(
                "Installation Timeout",
                "Installation timed out. If you clicked Install in the browser, "
                "the PWA should still be installed."
            )
        
        self.cleanup_after_install()
    
    def cleanup_after_install(self):
        """Cleanup after installation attempt"""
        if self.server_manager:
            self.server_manager.stop()
            self.server_manager = None
        
        self.processor.cleanup()
        
        # Reset GUI
        self.app_name_label.config(text="App Name: (not loaded)")
        self.install_button.config(text="Install PWA", state=tk.DISABLED)
        self.update_status("Ready")
    
    def update_status(self, message: str):
        """Update status label"""
        self.status_label.config(text=f"Status: {message}")
        self.root.update_idletasks()
    
    def show_error(self, message: str):
        """Show error dialog"""
        messagebox.showerror("Error", message)
```

### Measure
**Success Criteria:**
- [ ] Drag-and-drop triggers full processing pipeline
- [ ] Status updates show at each step
- [ ] Install button enables after successful zip processing
- [ ] Browser launches on install click
- [ ] Installation detection works
- [ ] Success message shows on completion
- [ ] Cleanup occurs after success or error
- [ ] Error messages are user-friendly

**End-to-End Test:**
1. Drop valid PWA zip
2. Verify app name appears
3. Verify install button enabled
4. Click install button
5. Verify browser opens
6. Click install in browser
7. Verify success message appears
8. Verify temp files cleaned up

### Analyze
**Performance Targets:**
- Full workflow (drop to browser open): < 5 seconds
- GUI remains responsive throughout
- No memory leaks after cleanup

**Quality Checks:**
- All errors handled gracefully
- Status updates visible to user
- Browser opens to correct URL
- Temp files always cleaned up

### Decide
**Decision Criteria:**
- If integration issues: Debug component interactions
- If performance slow: Optimize bottlenecks
- If GUI freezes: Move more work to background threads

**Next Steps:**
- ✅ Integration works end-to-end → Proceed to Task 8
- ❌ Workflow incomplete → Debug failing steps
- ❌ GUI unresponsive → Add threading

---

## Task 8: Packaging and Distribution

### Build
**Objective:** Package application as standalone Windows executable

**Deliverables:**
- PyInstaller build script
- Single-file executable
- Basic README for users
- Testing on clean Windows machine

**Implementation Steps:**

```python
# build.py
import PyInstaller.__main__
import os

# Clean previous builds
if os.path.exists('dist'):
    import shutil
    shutil.rmtree('dist')
if os.path.exists('build'):
    import shutil
    shutil.rmtree('build')

# Build executable
PyInstaller.__main__.run([
    'pwa_installer.py',
    '--onefile',                    # Single executable
    '--windowed',                   # No console window
    '--name=PWA-Installer',
    '--icon=assets/icon.ico',       # Application icon
    '--hidden-import=PIL',
    '--hidden-import=PIL._tkinter_finder',
    '--collect-all=tkinter',
    '--optimize=2',
    '--clean',
])

print("\nBuild complete! Executable: dist/PWA-Installer.exe")
```

```markdown
# USER_GUIDE.txt
PWA Installer Tool
==================

Simple tool to install Progressive Web Apps (PWAs) on Windows.

Usage:
1. Run PWA-Installer.exe
2. Drag and drop your PWA zip file
3. Click the Install button
4. Click the Install button in your browser when prompted
5. Done! Find your app in the Start Menu

Requirements:
- Windows 10 or Windows 11
- Microsoft Edge, Chrome, Firefox, or Brave browser

Troubleshooting:
- If installation fails, ensure the zip contains a valid PWA with manifest.json
- If browser doesn't open, try selecting a different browser from the dropdown
- If you see a security warning, click "More info" → "Run anyway"

Version: 1.0
License: MIT
```

### Measure
**Success Criteria:**
- [ ] Executable builds without errors
- [ ] .exe file size < 25MB
- [ ] Application runs on clean Windows 10 machine
- [ ] Application runs on clean Windows 11 machine
- [ ] No console window appears
- [ ] All functionality works in packaged version
- [ ] Application icon displays correctly

**Testing Checklist:**
- [ ] Build completes successfully
- [ ] Executable runs on development machine
- [ ] Test on clean VM (Windows 10)
- [ ] Test on clean VM (Windows 11)
- [ ] Test with various PWA zip files
- [ ] Test error scenarios
- [ ] Verify temp file cleanup
- [ ] Verify no leftover processes

### Analyze
**Performance Targets:**
- Build time: < 2 minutes
- Executable size: < 25MB (target: 15-20MB)
- Cold start time: < 3 seconds

**Quality Checks:**
- All dependencies included
- No import errors
- Temp files in correct location
- Executable signed (optional for MVP)

### Decide
**Decision Criteria:**
- If build fails: Check PyInstaller version, dependencies
- If exe too large: Remove unused dependencies
- If imports missing: Add hidden imports
- If testing reveals bugs: Fix and rebuild

**Next Steps:**
- ✅ Executable tested successfully → Project complete!
- ❌ Build issues → Debug PyInstaller configuration
- ❌ Runtime errors → Add missing dependencies

---

## Project Completion Checklist

### Functionality
- [ ] Zip extraction works
- [ ] Manifest validation works
- [ ] Icon generation works
- [ ] Server starts and serves files
- [ ] Browser detection works
- [ ] Browser launching works
- [ ] Installation detection works
- [ ] Cleanup completes
- [ ] Error handling works

### Quality
- [ ] User-friendly error messages
- [ ] GUI responsive
- [ ] No memory leaks
- [ ] Temp files cleaned up
- [ ] No security vulnerabilities

### Distribution
- [ ] Executable builds
- [ ] Runs on Windows 10
- [ ] Runs on Windows 11
- [ ] README provided
- [ ] File size acceptable

### Documentation
- [ ] Code comments complete
- [ ] README accurate
- [ ] Known limitations documented
