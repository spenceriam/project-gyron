# PWA Installer Tool - Requirements Document

## Project Overview

### Project Name
PWA Installer Tool

### Project Goal
Create a simple, user-friendly Windows desktop application that enables non-technical users to install Progressive Web Apps (PWAs) from zip files by automating icon generation, local server setup, and installation workflow management.

### Target Users
- Non-technical users unfamiliar with PWAs or command-line tools
- Users who receive PWA zip files and need to install them locally
- Users with basic computer skills (can drag/drop files, click buttons)

### Success Criteria
- User can install a PWA in under 2 minutes with zero technical knowledge
- Tool automatically handles all technical complexities (icon generation, server management, cleanup)
- Clear, simple instructions guide user through browser-based installation
- Works reliably across Edge, Chrome, Firefox, and Brave browsers
- Runs as standalone executable without requiring Python installation

## Core Requirements

### FR1: Zip File Processing
**Priority:** Must Have

**Description:** User provides PWA files via drag-and-drop of zip file

**Acceptance Criteria:**
- GUI accepts drag-and-drop of .zip files
- Automatically extracts zip to temporary directory
- Validates presence of manifest.json in extracted files
- Displays clear error if manifest.json missing or invalid JSON
- Shows extracted PWA name from manifest.json `name` field

**User Story:**
```
As a non-technical user
I want to drag a PWA zip file onto the tool
So that I can quickly start the installation process without file management
```

### FR2: Automatic Icon Generation
**Priority:** Must Have

**Description:** Tool automatically generates any missing PWA icons specified in manifest

**Acceptance Criteria:**
- Parses manifest.json for all icon entries (sizes, paths)
- Checks if icon files exist at specified paths
- Generates missing icons with blue-to-teal gradient background
- Extracts first letter from PWA name or start_url domain for icon text
- Creates white letter text on gradient background
- Saves generated icons to correct paths with correct sizes (192px, 512px, etc.)
- Works silently without user intervention

**Technical Details:**
- Uses PIL/Pillow for image generation
- Gradient: Blue (#0000FF) to Teal (#008080) top-to-bottom
- Text: White color, centered, sized proportionally to icon

**User Story:**
```
As a user receiving a PWA without proper icons
I want the tool to automatically create icons
So that the PWA can be installed without manual icon creation
```

### FR3: Browser Detection and Selection
**Priority:** Must Have

**Description:** Tool detects installed browsers and allows user to select which browser to use for installation

**Acceptance Criteria:**
- Automatically detects Microsoft Edge, Google Chrome, Mozilla Firefox, Brave on Windows
- Displays dropdown with detected browsers
- Sets Microsoft Edge as default selection if available
- Falls back to other browsers if Edge not installed
- Shows only browsers actually installed on system
- Validates browser executable exists before attempting launch

**Technical Details:**
- Checks standard Windows installation paths:
  - Edge: `C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe`
  - Chrome: `C:\Program Files\Google\Chrome\Application\chrome.exe`
  - Firefox: `C:\Program Files\Mozilla Firefox\firefox.exe`
  - Brave: `C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe`
- Alternative: Use Python `webbrowser` module for automatic detection

**User Story:**
```
As a user with multiple browsers
I want to choose which browser to use for PWA installation
So that I can install the PWA in my preferred browser
```

### FR4: Local HTTP Server Management
**Priority:** Must Have

**Description:** Tool automatically starts and manages local HTTP server for PWA installation

**Acceptance Criteria:**
- Starts Python's built-in HTTP server (`http.server` module)
- Attempts ports 8000-8009 to find available port
- Serves extracted PWA files from temporary directory
- Injects JavaScript to detect `appinstalled` event
- Automatically opens selected browser to `http://localhost:PORT`
- Stops server automatically after installation detected or timeout
- Cleans up server process on application exit

**Technical Details:**
- Server runs in background thread to keep GUI responsive
- Injects event listener script into index.html if present, or serves modified copy
- Listens for POST request to `/install-complete` endpoint from injected JS

**User Story:**
```
As a non-technical user
I want the server to start automatically
So that I don't need to understand or run terminal commands
```

### FR5: Installation Guidance and Detection
**Priority:** Must Have

**Description:** Tool provides clear instructions and detects when PWA installation completes

**Acceptance Criteria:**
- Displays large, clear instruction text: "Look for the Install button in your browser (usually in the address bar)"
- Shows visual indicator that installation is in progress
- Detects installation via `appinstalled` event (Chrome/Edge)
- Provides "I Clicked Install" button for user confirmation (Firefox/other browsers)
- Waits up to 2 minutes for installation before timeout
- Shows success message: "✓ {PWA Name} installed! Find it in your Start Menu"
- Automatically stops server and cleans temp files after success

**Technical Details:**
- Injects JavaScript: `window.addEventListener('appinstalled', () => { fetch('/install-complete', {method: 'POST'}) })`
- HTTP server catches POST to `/install-complete` and signals GUI
- Timeout fallback: 120 seconds
- Manual confirmation button immediately triggers completion

**User Story:**
```
As a user unfamiliar with PWAs
I want clear instructions on what to do in the browser
So that I can successfully complete the installation
```

### FR6: Automatic Cleanup
**Priority:** Must Have

**Description:** Tool automatically cleans up temporary files and server processes

**Acceptance Criteria:**
- Deletes temporary extracted PWA files after installation
- Stops HTTP server process cleanly
- Removes all temporary directories created during installation
- Handles cleanup even if user closes application mid-process
- No manual cleanup required from user

**User Story:**
```
As a user concerned about disk space
I want temporary files removed automatically
So that I don't accumulate clutter from installations
```

### FR7: Standalone Windows Executable
**Priority:** Must Have

**Description:** Tool distributes as single-file Windows executable

**Acceptance Criteria:**
- Packaged using PyInstaller with `--onefile --windowed` flags
- Runs on Windows 10 and Windows 11 without Python installation
- Bundles all dependencies (PIL/Pillow, tkinter, http.server)
- File size under 25MB
- No console window appears when running
- Includes application icon in executable

**User Story:**
```
As a user without Python installed
I want to run the tool as a simple .exe file
So that I don't need to install additional software
```

## Non-Functional Requirements

### NFR1: Performance
- Application launches in under 3 seconds
- Zip extraction completes in under 5 seconds for typical PWA (< 10MB)
- Icon generation completes in under 2 seconds per icon
- HTTP server starts in under 1 second
- GUI remains responsive throughout all operations

### NFR2: Usability
- Application window is simple, uncluttered design
- All text is readable with minimum 12pt font size
- Drag-and-drop zone is clearly labeled and visually distinct
- Progress indicators show during long operations
- Error messages are friendly, non-technical language
- No more than 2 user actions required (drag zip, click install button)

### NFR3: Reliability
- Handles corrupted zip files gracefully with clear error message
- Recovers from port conflicts by trying alternative ports
- Validates manifest.json structure before processing
- Handles missing or malformed icon paths in manifest
- Cleans up resources even if application crashes

### NFR4: Compatibility
- Works on Windows 10 (version 1809+) and Windows 11
- Supports Edge (Chromium-based), Chrome 90+, Firefox 80+, Brave
- Handles PWA manifests following Web App Manifest spec
- Supports common image formats for existing icons (PNG, JPG, SVG references)

### NFR5: Security
- Extracts zip files only to secure temporary directory
- Validates zip file contents before extraction (no path traversal)
- HTTP server only binds to localhost (not accessible externally)
- Temporary files deleted securely after use
- No data collection or network communication beyond localhost

## Out of Scope (Future Enhancements)

### Phase 2 Features
- PWA library management (persistent storage of installed PWAs)
- Custom icon upload/customization
- Multiple PWA installations in parallel
- Installation history and logs
- Automatic PWA updates from remote URLs
- GitHub Pages deployment integration
- Custom gradient color selection
- Advanced browser configuration options

### Explicitly Not Included in MVP
- PWA creation/editing tools
- Remote PWA hosting
- PWA store/marketplace features
- Mobile device PWA installation
- Linux/Mac support
- Command-line interface
- Batch installation of multiple PWAs

## Assumptions

1. **User Environment:**
   - User has Windows 10 or 11
   - User has at least one Chromium-based browser or Firefox installed
   - User has basic file system permissions (temp directory access)

2. **PWA Structure:**
   - PWA zip contains manifest.json in root or one level deep
   - Manifest follows standard Web App Manifest specification
   - PWA includes index.html as entry point
   - PWA is standalone (doesn't require build process)

3. **Technical:**
   - localhost is always available (not blocked by firewall)
   - Ports 8000-8009 are typically available
   - User has permissions to run executable files
   - PIL/Pillow can generate images in temp directory

## Constraints

### Technical Constraints
- Must use Python 3.8+ for PyInstaller compatibility
- GUI framework limited to tkinter (included in Python standard library)
- HTTP server must use Python standard library (http.server module)
- Image generation limited to PIL/Pillow capabilities

### Business Constraints
- Must be free, open-source tool
- No external dependencies requiring installation
- No cloud services or API requirements
- No user registration or authentication

### Time Constraints
- MVP must be completable in reasonable development timeframe
- Focus on core functionality over advanced features

## Success Metrics

### User Success Metrics
- 90%+ of users successfully install PWA on first attempt
- Average installation time under 2 minutes
- Less than 5% error rate from user actions
- No manual cleanup required

### Technical Success Metrics
- Application crashes occur in < 1% of installations
- Icon generation succeeds for 100% of valid manifests
- Server startup succeeds on 99%+ of attempts (port availability)
- Temporary file cleanup succeeds 100% of time

### Usability Metrics
- User requires zero technical documentation to complete installation
- Error messages enable user to self-resolve 80%+ of issues
- Application works without internet connection (after download)
