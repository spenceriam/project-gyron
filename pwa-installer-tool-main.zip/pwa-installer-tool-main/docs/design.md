# PWA Installer Tool - Technical Design Document

## System Architecture

### High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     PWA Installer Tool                       │
│                     (Windows Desktop App)                    │
└─────────────────────────────────────────────────────────────┘
                              │
        ┌─────────────────────┼─────────────────────┐
        │                     │                     │
        ▼                     ▼                     ▼
┌──────────────┐    ┌──────────────┐    ┌──────────────┐
│   GUI Layer  │    │ Processing   │    │   Server     │
│   (tkinter)  │◄───┤    Layer     │◄───┤   Manager    │
│              │    │              │    │ (http.server)│
└──────────────┘    └──────────────┘    └──────────────┘
                            │
                    ┌───────┴────────┐
                    │                │
                    ▼                ▼
            ┌──────────────┐ ┌──────────────┐
            │   Icon       │ │   Browser    │
            │   Generator  │ │   Launcher   │
            │   (PIL)      │ │              │
            └──────────────┘ └──────────────┘
```

### Component Interaction Flow

```
1. User drags PWA zip → GUI accepts drop
2. GUI → Processing Layer: Extract and validate
3. Processing Layer → Icon Generator: Create missing icons
4. Processing Layer → Server Manager: Start HTTP server
5. Server Manager → Browser Launcher: Open browser to localhost
6. Browser: User clicks "Install" button
7. Browser → Server (injected JS): POST /install-complete
8. Server → GUI: Installation detected
9. GUI: Show success, trigger cleanup
10. Processing Layer: Delete temp files, stop server
```

## Technology Stack

### Core Technologies

| Component | Technology | Version | Rationale |
|-----------|------------|---------|-----------|
| Language | Python | 3.8+ | Standard library includes all needed modules, easy packaging |
| GUI Framework | tkinter | Built-in | No external dependencies, native Windows look |
| Image Processing | Pillow (PIL) | 10.0+ | Industry standard, excellent gradient/text support |
| HTTP Server | http.server | Built-in | Simple, lightweight, sufficient for localhost |
| Browser Control | subprocess + webbrowser | Built-in | Reliable cross-browser launching |
| Packaging | PyInstaller | 6.0+ | Creates single-file Windows executables |

### Why Not Alternatives?

| Alternative | Reason Not Used |
|-------------|-----------------|
| PyQt/PySide | Requires large external dependencies, increases exe size |
| Flask/FastAPI | Overkill for simple static file serving |
| Electron | Would require Node.js, much larger executable |
| wxPython | External dependency, more complex than needed |

## Detailed Component Design

### 1. GUI Layer (tkinter)

**Purpose:** User interaction and visual feedback

**Key Classes:**

```python
class PWAInstallerGUI:
    """Main application window"""
    
    def __init__(self):
        self.root = tk.Tk()
        self.drop_zone = DropZone()
        self.browser_selector = BrowserDropdown()
        self.install_button = InstallButton()
        self.status_label = StatusLabel()
        self.progress_indicator = ProgressIndicator()
    
    def on_zip_dropped(self, zip_path):
        """Handle drag-and-drop event"""
        
    def on_install_clicked(self):
        """Handle install button click"""
        
    def show_success(self, app_name):
        """Display installation success message"""
        
    def show_error(self, error_message):
        """Display user-friendly error"""
```

**Layout Structure:**

```
┌──────────────────────────────────────────────┐
│  PWA Installer Tool                    [X]   │
├──────────────────────────────────────────────┤
│                                              │
│   ┌────────────────────────────────────┐    │
│   │                                    │    │
│   │   Drag PWA zip file here          │    │
│   │          or click to browse       │    │
│   │                                    │    │
│   └────────────────────────────────────┘    │
│                                              │
│   App Name: [Detected from manifest]        │
│                                              │
│   Browser: [Edge ▼]                          │
│                                              │
│   [ Install Gemini Enterprise ]             │
│                                              │
│   Status: Ready                              │
│                                              │
└──────────────────────────────────────────────┘
```

**Styling:**
- Window size: 500x400px (fixed, not resizable for simplicity)
- Font: Segoe UI, 12pt for body, 16pt for headers
- Colors: Windows default theme colors
- Drop zone: Dashed border, light gray background on hover
- Install button: Large (200x50px), primary color, disabled until zip loaded

### 2. Processing Layer

**Purpose:** Orchestrates extraction, validation, and coordination

**Key Classes:**

```python
class PWAProcessor:
    """Main processing coordinator"""
    
    def __init__(self):
        self.temp_dir = None
        self.manifest = None
        self.pwa_name = None
    
    def extract_zip(self, zip_path: str) -> str:
        """Extract zip to temporary directory"""
        # Returns: path to extracted directory
        
    def validate_manifest(self, extracted_path: str) -> dict:
        """Find and validate manifest.json"""
        # Returns: parsed manifest dict
        # Raises: ManifestNotFoundError, ManifestInvalidError
        
    def get_pwa_name(self) -> str:
        """Extract PWA name from manifest"""
        # Tries: manifest['name'], manifest['short_name'], start_url domain
        
    def cleanup(self):
        """Remove temporary files and directories"""
```

**Error Handling Strategy:**

```python
class PWAInstallerError(Exception):
    """Base exception with user-friendly messages"""
    
class ManifestNotFoundError(PWAInstallerError):
    message = "This zip doesn't contain a valid PWA. Missing manifest.json file."
    
class ManifestInvalidError(PWAInstallerError):
    message = "The PWA's manifest.json file is corrupted or invalid."
    
class PortUnavailableError(PWAInstallerError):
    message = "Cannot start server. Please close other applications and try again."
    
class BrowserNotFoundError(PWAInstallerError):
    message = "Selected browser not found. Please select a different browser."
```

### 3. Icon Generator

**Purpose:** Create missing PWA icons with gradient and text

**Key Classes:**

```python
class IconGenerator:
    """Generate PWA icons from manifest specs"""
    
    GRADIENT_START = (0, 0, 255)      # Blue
    GRADIENT_END = (0, 128, 128)      # Teal
    TEXT_COLOR = (255, 255, 255)       # White
    
    def __init__(self, manifest: dict, base_path: str):
        self.manifest = manifest
        self.base_path = base_path
        self.letter = self._extract_letter()
    
    def _extract_letter(self) -> str:
        """Get first letter from name or start_url"""
        # Priority: manifest['name'], manifest['short_name'], start_url domain
        
    def generate_missing_icons(self):
        """Create all missing icons from manifest"""
        for icon_entry in self.manifest.get('icons', []):
            if not self._icon_exists(icon_entry['src']):
                self._generate_icon(icon_entry)
    
    def _generate_icon(self, icon_entry: dict):
        """Generate single icon with gradient and text"""
        size = self._parse_size(icon_entry['sizes'])
        img = self._create_gradient(size)
        img = self._add_text(img, self.letter, size)
        self._save_icon(img, icon_entry['src'])
    
    def _create_gradient(self, size: int) -> Image:
        """Create vertical blue-to-teal gradient"""
        
    def _add_text(self, img: Image, letter: str, size: int) -> Image:
        """Add centered white letter text"""
        # Font size: ~60% of icon size
        # Font: Arial Bold or system default
```

**Icon Generation Algorithm:**

```python
def _create_gradient(self, size: int) -> Image:
    """
    Creates vertical gradient from blue to teal
    
    Algorithm:
    1. Create new RGB image of specified size
    2. For each row (y coordinate):
        - Calculate interpolation factor: y / height
        - Interpolate R, G, B values between start and end colors
        - Fill entire row with interpolated color
    """
    img = Image.new('RGB', (size, size))
    draw = ImageDraw.Draw(img)
    
    for y in range(size):
        ratio = y / size
        r = int(self.GRADIENT_START[0] + ratio * (self.GRADIENT_END[0] - self.GRADIENT_START[0]))
        g = int(self.GRADIENT_START[1] + ratio * (self.GRADIENT_END[1] - self.GRADIENT_START[1]))
        b = int(self.GRADIENT_START[2] + ratio * (self.GRADIENT_END[2] - self.GRADIENT_START[2]))
        draw.line([(0, y), (size, y)], fill=(r, g, b))
    
    return img

def _add_text(self, img: Image, letter: str, size: int) -> Image:
    """
    Adds centered white letter to image
    
    Algorithm:
    1. Calculate font size (60% of icon size)
    2. Load font (Arial Bold, fallback to default)
    3. Measure text bounding box
    4. Calculate center position
    5. Draw white text at center
    """
    draw = ImageDraw.Draw(img)
    font_size = int(size * 0.6)
    
    try:
        font = ImageFont.truetype("arialbd.ttf", font_size)
    except:
        font = ImageFont.load_default()
    
    bbox = draw.textbbox((0, 0), letter, font=font)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]
    
    x = (size - text_width) // 2
    y = (size - text_height) // 2
    
    draw.text((x, y), letter.upper(), fill=self.TEXT_COLOR, font=font)
    return img
```

### 4. Server Manager

**Purpose:** Manage local HTTP server for PWA serving

**Key Classes:**

```python
class PWAServerManager:
    """Manages HTTP server lifecycle"""
    
    PORT_RANGE = range(8000, 8010)
    TIMEOUT_SECONDS = 120
    
    def __init__(self, pwa_directory: str):
        self.directory = pwa_directory
        self.port = None
        self.server_thread = None
        self.server = None
        self.install_detected = threading.Event()
    
    def start(self) -> int:
        """Start server on available port"""
        # Returns: port number
        # Raises: PortUnavailableError if all ports busy
        
    def stop(self):
        """Stop server and cleanup"""
        
    def wait_for_installation(self) -> bool:
        """Wait for installation signal or timeout"""
        # Returns: True if installed, False if timeout
        
    def _inject_detection_script(self):
        """Inject appinstalled event listener into HTML"""
```

**Server Implementation:**

```python
class InstallDetectionHandler(http.server.SimpleHTTPRequestHandler):
    """Custom HTTP handler with install detection"""
    
    def do_POST(self):
        """Handle installation completion signal"""
        if self.path == '/install-complete':
            self.server.install_detected.set()
            self.send_response(200)
            self.end_headers()
    
    def do_GET(self):
        """Serve files with injected detection script"""
        if self.path == '/' or self.path == '/index.html':
            # Inject detection script into HTML
            html = self._read_and_inject()
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            self.wfile.write(html.encode())
        else:
            # Serve other files normally
            super().do_GET()
    
    def _read_and_inject(self) -> str:
        """Read HTML and inject detection script"""
        with open('index.html', 'r') as f:
            html = f.read()
        
        injection = """
        <script>
        window.addEventListener('appinstalled', () => {
            fetch('/install-complete', {method: 'POST'});
        });
        </script>
        """
        
        # Inject before </body> or </head>
        if '</body>' in html:
            html = html.replace('</body>', injection + '</body>')
        elif '</head>' in html:
            html = html.replace('</head>', injection + '</head>')
        else:
            html += injection
        
        return html
```

**Port Selection Algorithm:**

```python
def _find_available_port(self) -> int:
    """
    Try ports 8000-8009 until one is available
    
    Algorithm:
    1. Iterate through PORT_RANGE
    2. For each port:
        - Try to create socket and bind
        - If successful: close socket, return port
        - If failed (port busy): continue to next
    3. If all ports busy: raise PortUnavailableError
    """
    for port in self.PORT_RANGE:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(('localhost', port))
                return port
        except OSError:
            continue
    
    raise PortUnavailableError()
```

### 5. Browser Launcher

**Purpose:** Detect and launch browsers

**Key Classes:**

```python
class BrowserLauncher:
    """Detect and launch browsers"""
    
    BROWSER_PATHS = {
        'Microsoft Edge': [
            r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
            r'C:\Program Files\Microsoft\Edge\Application\msedge.exe'
        ],
        'Google Chrome': [
            r'C:\Program Files\Google\Chrome\Application\chrome.exe',
            r'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe'
        ],
        'Mozilla Firefox': [
            r'C:\Program Files\Mozilla Firefox\firefox.exe',
            r'C:\Program Files (x86)\Mozilla Firefox\firefox.exe'
        ],
        'Brave': [
            r'C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe',
            r'C:\Program Files (x86)\BraveSoftware\Brave-Browser\Application\brave.exe'
        ]
    }
    
    def __init__(self):
        self.available_browsers = self._detect_browsers()
    
    def _detect_browsers(self) -> dict:
        """Detect installed browsers"""
        found = {}
        for name, paths in self.BROWSER_PATHS.items():
            for path in paths:
                if os.path.exists(path):
                    found[name] = path
                    break
        return found
    
    def launch(self, browser_name: str, url: str):
        """Launch browser with URL"""
        if browser_name not in self.available_browsers:
            raise BrowserNotFoundError()
        
        browser_path = self.available_browsers[browser_name]
        subprocess.Popen([browser_path, url])
```

## Data Flow

### Installation Flow Diagram

```
┌─────────┐
│  User   │
│ drops   │
│  zip    │
└────┬────┘
     │
     ▼
┌─────────────────────┐
│ Extract to temp dir │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ Find manifest.json  │
│ Parse and validate  │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ Check for missing   │
│ icons in manifest   │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ Generate missing    │
│ icons with gradient │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ Find available port │
│ Start HTTP server   │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ Launch browser to   │
│ http://localhost:P  │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ User clicks install │
│ in browser          │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ Browser fires       │
│ appinstalled event  │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ JS sends POST to    │
│ /install-complete   │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ Server detects,     │
│ signals GUI         │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ Show success msg    │
│ Stop server         │
│ Delete temp files   │
└─────────────────────┘
```

## File Structure

```
pwa-installer/
├── pwa_installer.py          # Main application entry point
├── gui/
│   ├── __init__.py
│   ├── main_window.py        # Main GUI class
│   ├── widgets.py            # Custom widgets (drop zone, etc.)
│   └── styles.py             # GUI styling constants
├── core/
│   ├── __init__.py
│   ├── processor.py          # PWA processing logic
│   ├── icon_generator.py    # Icon generation
│   ├── server_manager.py    # HTTP server management
│   └── browser_launcher.py  # Browser detection/launch
├── utils/
│   ├── __init__.py
│   ├── exceptions.py         # Custom exceptions
│   └── validators.py         # Validation helpers
├── assets/
│   └── icon.ico              # Application icon
├── requirements.txt          # Python dependencies
├── build.py                  # PyInstaller build script
└── README.md
```

## Packaging Strategy

### PyInstaller Configuration

```python
# build.py
import PyInstaller.__main__

PyInstaller.__main__.run([
    'pwa_installer.py',
    '--onefile',              # Single executable
    '--windowed',             # No console window
    '--name=PWA-Installer',
    '--icon=assets/icon.ico',
    '--add-data=assets;assets',
    '--hidden-import=PIL',
    '--hidden-import=PIL._tkinter_finder',
    '--collect-all=tkinter',
    '--optimize=2',
])
```

### Deployment Package

```
PWA-Installer-v1.0/
├── PWA-Installer.exe        # Main executable (~20MB)
├── USER_GUIDE.txt           # End-user instructions
└── LICENSE.txt              # License information
```

## Security Considerations

### Threat Model

| Threat | Mitigation |
|--------|------------|
| Malicious zip extraction (path traversal) | Validate all paths before extraction, use safe extraction |
| External network access | Server binds only to localhost, firewall-friendly |
| Temporary file exposure | Use secure temp directory, delete immediately after use |
| Browser exploitation | No custom browser code, uses standard PWA install flow |

### Secure Extraction

```python
def safe_extract_zip(zip_path: str, extract_to: str):
    """
    Securely extract zip file preventing path traversal
    
    Validates:
    - No absolute paths in zip
    - No paths with '..' components
    - All files extract within target directory
    """
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        for member in zip_ref.namelist():
            # Check for path traversal
            if member.startswith('/') or '..' in member:
                raise InvalidZipError("Zip contains invalid paths")
            
            # Validate extracted path stays within target
            target_path = os.path.join(extract_to, member)
            if not target_path.startswith(os.path.abspath(extract_to)):
                raise InvalidZipError("Zip contains invalid paths")
        
        # Safe to extract
        zip_ref.extractall(extract_to)
```

## Performance Optimization

### Optimization Strategies

1. **Lazy Loading:** Only generate icons when needed, not upfront
2. **Threading:** Run server in separate thread to keep GUI responsive
3. **Caching:** Cache browser detection results (don't re-scan on each launch)
4. **Efficient Cleanup:** Use OS-level temp directory with automatic cleanup

### Expected Performance

| Operation | Target Time | Method |
|-----------|-------------|--------|
| Application startup | < 3 sec | Optimized imports, lazy initialization |
| Zip extraction (5MB) | < 2 sec | Native Python zipfile module |
| Icon generation (512px) | < 1 sec | PIL optimized image operations |
| Server startup | < 1 sec | Lightweight http.server module |
| Browser launch | < 2 sec | OS subprocess, no delays |

## Error Recovery

### Recovery Strategies

```python
def install_pwa_with_recovery():
    """
    Main installation flow with error recovery
    """
    try:
        # Normal flow
        extract_zip()
        validate_manifest()
        generate_icons()
        start_server()
        launch_browser()
        wait_for_installation()
        
    except ManifestNotFoundError as e:
        # User error - show friendly message
        show_error(e.message)
        
    except PortUnavailableError as e:
        # Recoverable - suggest actions
        show_error_with_retry(e.message, "Close other apps and try again")
        
    except Exception as e:
        # Unexpected error - log and show generic message
        log_error(e)
        show_error("Something went wrong. Please try again.")
        
    finally:
        # Always cleanup
        cleanup_temp_files()
        stop_server()
```

## Testing Strategy

### Unit Tests
- Icon generation with various letter inputs
- Gradient color interpolation
- Manifest parsing edge cases
- Port finding algorithm
- Browser detection on different systems

### Integration Tests
- Full installation flow end-to-end
- Error scenarios (missing manifest, no ports available)
- Multi-browser compatibility
- Cleanup verification

### Manual Testing Checklist
- [ ] Install PWA in Edge
- [ ] Install PWA in Chrome
- [ ] Install PWA in Firefox
- [ ] Test with missing icons
- [ ] Test with invalid manifest
- [ ] Test with all ports busy
- [ ] Verify cleanup after success
- [ ] Verify cleanup after error
- [ ] Test on Windows 10
- [ ] Test on Windows 11

## Future Enhancements

### Planned Improvements
1. **Persistent PWA Library:** Save installed PWAs for later re-installation
2. **Custom Icon Upload:** Allow user to provide custom icons
3. **Remote PWA Installation:** Install from URL instead of zip
4. **Auto-Update Detection:** Check for PWA updates periodically
5. **Installation History:** Track installed PWAs with timestamps
6. **Multiple Simultaneous Installs:** Run multiple servers on different ports
7. **Advanced Logging:** Detailed logs for troubleshooting
8. **Themes:** Light/dark mode support

### Architecture Extensibility
- Plugin system for custom icon generators
- Config file for advanced users
- API for programmatic usage
- CLI mode for automation
