# PWA Installer Tool - Project Memory (AGENTS.md)

## Project Identity

### Project Name
PWA Installer Tool

### Project Description
A Windows desktop application that enables non-technical users to install Progressive Web Apps (PWAs) from zip files through an intuitive drag-and-drop interface with automated icon generation and installation workflow management.

### Project Version
0.0.1 (Initial Development)

### Project Type
Desktop utility application

### Target Platform
Windows 10 and Windows 11

### Development Language
Python 3.8+

### Key Stakeholders
- **End Users:** Non-technical Windows users who need to install PWAs
- **Developer:** Creating tool for personal/organizational use
- **Recipients:** Users receiving PWA zip files for installation

## Project Context

### Problem Statement
Users receive PWA zip files (e.g., "gemini-enterprise" PWA) but lack technical knowledge to:
- Set up local HTTP servers for PWA testing
- Generate missing icon files
- Understand PWA installation process in browsers
- Manage temporary files and cleanup

Current process requires:
- Command-line knowledge (Python, http.server)
- Understanding of localhost and ports
- Manual icon creation
- Knowledge of PWA installation requirements

### Solution Approach
Create standalone Windows executable that:
1. Accepts PWA zip files via drag-and-drop
2. Automatically validates and processes PWA files
3. Generates missing icons with branded gradients
4. Starts local HTTP server automatically
5. Launches browser with clear installation instructions
6. Detects installation completion
7. Cleans up all temporary files

### Key Innovation
**Frictionless installation:** User only performs 2 actions (drag zip, click install), tool handles all technical complexity automatically.

## Technical Decisions

### Decision 1: Technology Stack
**Decision:** Python + tkinter + PyInstaller  
**Rationale:**
- Python's standard library includes http.server (no external web server needed)
- tkinter included with Python (no GUI dependencies)
- Pillow (PIL) is mature, reliable for image generation
- PyInstaller creates single-file Windows executables
- All technologies proven, stable, well-documented

**Alternatives Considered:**
- Electron: Rejected (too large, requires Node.js)
- .NET/C#: Rejected (requires more complex setup, less portable)
- Go: Rejected (less mature GUI libraries, harder image processing)

**Trade-offs:**
- ✅ Zero external runtime dependencies
- ✅ Small executable size (~20MB)
- ✅ Fast development with Python
- ❌ Python somewhat slower than compiled languages (acceptable for this use case)

### Decision 2: Icon Generation Strategy
**Decision:** Blue-to-teal gradient with white first letter  
**Rationale:**
- Simple, professional appearance
- Distinctive and recognizable
- Fast to generate (no complex graphics)
- Works for any PWA name
- Accessible color contrast (white on dark gradient)

**Alternatives Considered:**
- Solid color: Rejected (less visually interesting)
- Random colors: Rejected (inconsistent branding)
- Download from icon service: Rejected (requires internet, privacy concerns)

**Implementation:**
- Gradient: RGB(0,0,255) to RGB(0,128,128) vertical
- Letter: First character of PWA name or start_url domain
- Font: Arial Bold, fallback to system default
- Sizes: Dynamically generated based on manifest requirements

### Decision 3: Browser Detection Approach
**Decision:** Check standard Windows installation paths  
**Rationale:**
- Reliable for most installations
- No registry access needed (simpler, safer)
- Covers Edge, Chrome, Firefox, Brave
- Fast detection (< 200ms)

**Alternatives Considered:**
- Windows Registry lookup: Rejected (more complex, security concerns)
- Python webbrowser module only: Rejected (less control over browser selection)
- Ask user to select manually: Rejected (poor UX for non-technical users)

**Implementation:**
- Check predefined paths in both Program Files locations
- Prioritize Microsoft Edge (native Windows browser)
- Allow user to select from detected browsers

### Decision 4: Installation Detection Method
**Decision:** JavaScript `appinstalled` event + HTTP POST callback + timeout fallback  
**Rationale:**
- `appinstalled` event is standard Web Manifest API
- Works in Chrome and Edge (most common browsers)
- HTTP POST to server enables GUI notification
- 2-minute timeout handles Firefox/other browsers
- User can also click "I Installed" button for manual confirmation

**Alternatives Considered:**
- Server log monitoring: Rejected (unreliable, sw.js might be cached)
- Polling browser process: Rejected (no reliable way to detect PWA install)
- Manual confirmation only: Rejected (less automated, worse UX)

**Implementation:**
```javascript
// Injected into served HTML
window.addEventListener('appinstalled', () => {
    fetch('/install-complete', {method: 'POST'});
});
```

### Decision 5: Temporary File Management
**Decision:** Python's `tempfile.mkdtemp()` with immediate cleanup  
**Rationale:**
- OS-managed temp directory (respects system settings)
- Automatic permission handling
- Unique directory per invocation (no conflicts)
- Standard Python approach (well-tested)

**Cleanup Strategy:**
- Delete temp directory after installation success
- Delete temp directory on error
- Delete temp directory on application exit
- OS eventually cleans temp files if app crashes

### Decision 6: Error Handling Philosophy
**Decision:** User-friendly messages, minimal technical details (MVP)  
**Rationale:**
- Target users are non-technical
- Generic errors reduce support burden
- MVP focuses on happy path
- Detailed logging can be added in future versions

**Error Messages:**
- "This zip doesn't contain a valid PWA. Missing manifest.json file."
- "The PWA's manifest.json file is corrupted or invalid."
- "Cannot start server. Please close other applications and try again."
- "Selected browser not found. Please select a different browser."

**What We Don't Do (MVP):**
- Detailed error logs
- Crash reporting
- Diagnostic information collection
- Advanced troubleshooting guides

### Decision 7: Packaging Approach
**Decision:** PyInstaller with `--onefile --windowed` flags  
**Rationale:**
- Single .exe file (easiest distribution)
- No console window (professional appearance)
- Bundles all dependencies (no installation needed)
- Industry standard for Python executables

**Build Configuration:**
- `--onefile`: Single executable (not directory)
- `--windowed`: No console window
- `--optimize=2`: Bytecode optimization for smaller size
- `--icon`: Custom application icon

**Trade-offs:**
- ✅ Simplest user experience
- ✅ Easy distribution (single file)
- ❌ Slower first launch (extraction from bundle)
- ❌ Larger file size than --onedir (acceptable for convenience)

## Risk Assessment

### Technical Risks

#### Risk 1: Port Conflicts
**Probability:** Medium  
**Impact:** Medium  
**Mitigation:**
- Try ports 8000-8009 (10 options)
- Most users won't have all ports occupied
- Clear error message if all ports busy
- Future: Allow user to close conflicting apps or extend range

#### Risk 2: Browser Detection Failure
**Probability:** Low  
**Impact:** Medium  
**Mitigation:**
- Support 4 major browsers (Edge, Chrome, Firefox, Brave)
- Most Windows users have at least one
- Error message suggests installing browser
- Future: Fallback to default system browser

#### Risk 3: Icon Generation Performance
**Probability:** Low  
**Impact:** Low  
**Mitigation:**
- PIL is highly optimized
- Icons small (512x512 max)
- Generation cached (not regenerated)
- Async generation possible if needed

#### Risk 4: PyInstaller Compatibility
**Probability:** Low  
**Impact:** High  
**Mitigation:**
- PyInstaller mature, widely used
- Standard Python libraries well-supported
- Test on multiple Windows versions
- Alternative: cx_Freeze if PyInstaller fails

### User Experience Risks

#### Risk 1: User Doesn't Click Install in Browser
**Probability:** Medium  
**Impact:** Medium  
**Mitigation:**
- Clear on-screen instructions
- Status message: "Look for Install button in address bar"
- 2-minute timeout gives time to read and act
- Manual confirmation button as backup
- Future: Screenshot/visual guide

#### Risk 2: User Closes Application Mid-Install
**Probability:** Low  
**Impact:** Low  
**Mitigation:**
- Temp files in OS temp directory (auto-cleanup eventually)
- No permanent system changes
- User can restart and retry
- Future: Confirmation dialog on close during installation

#### Risk 3: Antivirus False Positive
**Probability:** Medium  
**Impact:** High  
**Mitigation:**
- Code signing (future)
- Clear branding in executable
- README explains security warning
- Distribute from known source
- Future: Submit to antivirus vendors for whitelisting

## External Dependencies

### Runtime Dependencies (Bundled)
- **Python Standard Library:** http.server, tkinter, zipfile, json, threading, subprocess
- **Pillow (PIL):** Image generation and manipulation
- **PyInstaller:** Packaging tool (build-time only)

### System Requirements
- **OS:** Windows 10 (version 1809+) or Windows 11
- **Browser:** Edge (Chromium), Chrome 90+, Firefox 80+, or Brave
- **Disk Space:** ~25MB for executable, ~50MB temp space during installation
- **Network:** None (localhost only)

### No External Services
- ✅ No internet connection required
- ✅ No API keys or accounts needed
- ✅ No data collection or telemetry
- ✅ No cloud storage or remote servers

## Project Constraints

### Time Constraints
- **MVP Scope:** Focus on core functionality only
- **Feature Freeze:** No advanced features until MVP validated
- **Testing Window:** Must test on Windows 10 and 11 before release

### Technical Constraints
- **Python Version:** 3.8+ (PyInstaller compatibility)
- **GUI Framework:** tkinter only (no external GUI dependencies)
- **Image Processing:** PIL/Pillow only (standard, reliable)
- **Packaging:** Single-file executable (user convenience priority)

### Business Constraints
- **Cost:** $0 (all free, open-source tools)
- **Licensing:** MIT or similar permissive license
- **Distribution:** Direct download (no app stores initially)
- **Support:** Minimal (README documentation only for MVP)

### Scope Constraints (Out of MVP)
- ❌ PWA creation/editing tools
- ❌ Remote PWA hosting/deployment
- ❌ PWA marketplace or store
- ❌ Automatic PWA updates
- ❌ Mobile device installation
- ❌ Linux or macOS support
- ❌ Command-line interface
- ❌ Batch installation of multiple PWAs
- ❌ Custom gradient color selection
- ❌ Advanced logging or diagnostics
- ❌ PWA library/management features

## Development Guidelines

### Code Style
- Follow PEP 8 (Python style guide)
- Clear variable and function names
- Type hints where helpful
- Docstrings for classes and public methods
- Comments for complex logic only

### Testing Approach
- Manual testing for MVP
- Focus on happy path validation
- Test all error scenarios
- Test on clean Windows VMs
- Test with variety of PWA zip files

### Documentation Standards
- User-facing: Non-technical, friendly language
- Code comments: Explain why, not what
- README: Simple, step-by-step instructions
- Error messages: Actionable, no jargon

## Success Criteria

### MVP Success Metrics
- ✅ User can install PWA in under 2 minutes
- ✅ Zero technical knowledge required
- ✅ Works with 95%+ of valid PWA zip files
- ✅ Executable runs on Windows 10 and 11 without installation
- ✅ Error rate < 5% for valid PWAs
- ✅ User receives clear feedback at each step
- ✅ Temporary files cleaned up 100% of time
- ✅ No manual cleanup ever required

### Post-MVP Goals
- Add persistent PWA library
- Custom icon upload capability
- Remote PWA installation from URLs
- Installation history and management
- Automatic update checking
- Multi-language support
- Dark mode UI theme
- Enhanced error logging

## Known Limitations

### Current MVP Limitations
1. **Single Installation at a Time:** Cannot install multiple PWAs simultaneously
2. **No Installation History:** No record of previously installed PWAs
3. **Limited Browser Support:** Only Edge, Chrome, Firefox, Brave
4. **Windows Only:** No Linux or macOS support
5. **Manual Browser Install:** User must click install button in browser
6. **Fixed Icon Style:** Blue-to-teal gradient only
7. **No Custom Icons:** Cannot upload custom icon files
8. **Minimal Logging:** Limited diagnostic information
9. **No Auto-Updates:** Must manually download new versions
10. **English Only:** No internationalization

### Workarounds
- **Single Installation:** Wait for completion before installing next PWA
- **Browser Support:** Install supported browser if needed
- **Manual Install:** Clear instructions provided on-screen
- **Custom Icons:** Edit PWA zip before installation

## Future Roadmap

### Phase 2 Features (Post-MVP)
1. **PWA Library Management**
   - Store installed PWAs for re-installation
   - Track installation history
   - Quick re-install capability

2. **Enhanced Icon Customization**
   - Custom gradient colors
   - Upload custom icons
   - Icon preview before generation

3. **Advanced Installation**
   - Install from URL (remote PWAs)
   - Batch installation of multiple PWAs
   - Silent/automated installation mode

4. **Improved UX**
   - Visual installation guide with screenshots
   - Dark mode theme
   - Multi-language support (Spanish, French, German, Japanese)

5. **Management Features**
   - Update checking for installed PWAs
   - Uninstall integration
   - PWA settings management

### Phase 3 Features (Long-term)
- Cross-platform support (Linux, macOS)
- GitHub Pages deployment integration
- PWA creation wizard
- Command-line interface
- Cloud sync of PWA library
- PWA marketplace integration

## Project History

### Initial Request
User has "gemini-enterprise" PWA folder with index.html, manifest.json, sw.js and needs to:
- Run locally to test PWA installation
- Install the PWA on Windows without technical knowledge

### Evolution of Requirements
1. **Started with:** "How to run PWA locally?"
2. **Evolved to:** "How to install PWA locally?"
3. **Refined to:** "Need reusable solution for any PWA"
4. **Final scope:** "GUI tool for non-technical users"

### Key Decision Points
1. **Local vs Remote:** Decided local-only for MVP (simpler, more private)
2. **CLI vs GUI:** Chose GUI for non-technical users
3. **Manual vs Automatic:** Maximized automation (icon gen, server, cleanup)
4. **Browser Control:** User selects browser, tool opens but user clicks install

### Lessons Learned
1. **Localhost is Secure:** Modern browsers treat localhost as secure context (no HTTPS needed)
2. **No Programmatic Install:** Browsers don't allow command-line PWA installation for security
3. **Event Detection:** `appinstalled` event works well in Chrome/Edge
4. **PyInstaller Works:** Creates reliable single-file executables

## Development Status

### Current Phase
Implementation in progress with focus on UX reliability and offline launch correctness.

### Next Steps
1. Validate improved install button visibility without requiring DevTools.
2. Confirm service worker shell page cache integrity via new `[SW]` logs.
3. Add tests for manifest rewriting and shell redirect logic.
4. Prepare packaging once redirect reliability confirmed.
5. Consider optional troubleshooting panel (future minor enhancement).

### Recent Modifications (2025-11-19)
- Install landing page button now rendered immediately (disabled until `beforeinstallprompt` fires). Timeout fallback enables manual address bar install hint.
- Service worker enhanced with detailed logging (`[SW]`) for install, activate, and navigation fetch events; improved error handling if shell page caching fails.
- Shell redirect page includes multi-attempt timed redirects and console diagnostics (`[Shell]` logs) for offline launch debugging.
- Renamed end-user guide from `README.txt` to `USER_GUIDE.txt` to avoid confusion with repository README.md.
- Removed obsolete `IMPLEMENTATION_SUMMARY.md` (info covered by this file and design docs).

### Blockers
None currently identified

### Open Questions
Need confirmation that cached shell page consistently launches target URL post-install on a fresh system without DevTools interaction. Monitoring any remaining white-screen occurrences.

## Maintenance Plan

### Version Control
- Git repository recommended
- Tag releases (v1.0.0, v1.1.0, etc.)
- Maintain changelog

### Update Strategy
- Distribute new .exe for updates
- No auto-update in MVP
- Users download manually

### Support Strategy
- README for common issues
- GitHub Issues for bug reports (if open source)
- No direct support for MVP

## Contact and Resources

### Documentation
- **Requirements:** See requirements.md
- **Design:** See design.md
- **Tasks:** See tasks.md
- **This File:** Project memory and context

### Key Concepts
- **PWA:** Progressive Web App - installable web application
- **Manifest:** JSON file defining PWA metadata and icons
- **Service Worker:** JavaScript enabling offline functionality
- **localhost:** Local server address (127.0.0.1) treated as secure
- **appinstalled Event:** Web API event fired when PWA installed

### Useful References
- [MDN: Progressive Web Apps](https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps)
- [Web App Manifest Spec](https://www.w3.org/TR/appmanifest/)
- [Microsoft Edge PWA Documentation](https://learn.microsoft.com/en-us/microsoft-edge/progressive-web-apps/)
- [PyInstaller Documentation](https://pyinstaller.org/en/stable/)
- [Pillow Documentation](https://pillow.readthedocs.io/)

---

## For AI Agents

### Context Summary
This is a Windows desktop tool for installing Progressive Web Apps from zip files. The target user is non-technical. The tool must be completely self-contained (single .exe) and handle all complexity automatically (icon generation, server management, cleanup).

### Implementation Priorities
1. **User Experience:** Must be trivial to use (drag, click, done)
2. **Reliability:** Must work on clean Windows installs
3. **Cleanup:** Must never leave files or processes behind
4. **Error Handling:** Must provide friendly, actionable messages

### Key Constraints
- Python 3.8+ only
- tkinter for GUI (no external dependencies)
- Single-file executable (PyInstaller --onefile)
- Windows 10/11 only
- MVP scope (no advanced features)

### Testing Checklist
Before marking complete, verify:
- ✅ Runs on Windows 10 VM
- ✅ Runs on Windows 11 VM
- ✅ Works with test PWA zips
- ✅ Handles errors gracefully
- ✅ Cleanup always succeeds
- ✅ Browser launches correctly
- ✅ Installation detected
- ✅ User receives clear feedback

### Quick Start for Implementation
1. Follow tasks.md in order (Task 1 → Task 8)
2. Test after each task completion
3. Use BMAD methodology (Build → Measure → Analyze → Decide)
4. Refer to design.md for implementation details
5. Check requirements.md for acceptance criteria
6. Use this file for context and decisions

---

## Version Bumping Protocol

**CRITICAL: AI agents MUST ASK USER for version bump approval. Never bump versions autonomously.**

AI agents MUST follow this semantic versioning workflow when creating PRs or releases.

### Semantic Versioning Format

Version numbers follow the format: **MAJOR.MINOR.PATCH** (e.g., 1.2.3)

- **MAJOR (X.0.0)**: Breaking changes, API changes, architectural overhauls
  - Example: 1.5.2 → 2.0.0
- **MINOR (0.X.0)**: New features, new components, significant enhancements (backwards compatible)
  - Example: 1.5.2 → 1.6.0
- **PATCH (0.0.X)**: Bug fixes, typos, minor tweaks, performance improvements (backwards compatible)
  - Example: 1.5.2 → 1.5.3

### AI Agent Workflow for Version Bumping

**Step 1: Analyze Changes**
Before creating a PR or release, review all changes and categorize them.

**Step 2: Ask User for Confirmation**
Present your analysis to the user and ask for confirmation:

```
Based on the changes in this branch, I've identified:
- [List key changes]

I recommend a [PATCH/MINOR/MAJOR] version bump because [reasoning].

Current version: X.Y.Z
Proposed version: X.Y.Z

Does this classification seem correct? Should I proceed with this version bump?
```

**Step 3: Update Version in package.json**
Update the version field in `package.json`:

```json
{
  "version": "X.Y.Z"
}
```

**Step 4: Apply Version Bump**
After user confirmation, bump the version:

```bash
# Manually edit package.json with new version
git add package.json
git commit -m "Bump version to vX.Y.Z"
git tag -a vX.Y.Z -m "Version X.Y.Z"
git push && git push --tags
```

**Step 5: Document in Release Notes**
- Create release notes explaining what changed
- Mention version bump and reasoning
- List user-facing changes
- Include any breaking changes or migration notes

### Decision Tree for AI Agents

**MAJOR bump (X.0.0)** - Use when:
- Removing or renaming public components or APIs
- Changing command-line interface in breaking ways
- Restructuring application architecture
- Changing build output or deployment requirements
- Any change that requires users to modify their usage

**MINOR bump (0.X.0)** - Use when:
- Adding new feature or component
- Adding new command-line options (backwards compatible)
- Significant enhancement to existing feature
- Adding new functionality
- New user-facing capabilities

**PATCH bump (0.0.X)** - Use when:
- Fixing bugs or errors
- Correcting typos in UI text
- Improving error messages or logging
- GUI styling fixes or adjustments
- Performance optimizations (no API changes)
- Security patches
- Dependency updates (no breaking changes)

**SKIP version bump** - Use when:
- Updating documentation only (README, comments)
- Modifying AGENTS.md or workflow files
- Changing .gitignore or similar tooling files
- Updating test files without code changes

### Examples

**PATCH: 0.0.1 → 0.0.2**
- "Fix icon generation font fallback issue"
- "Correct error handling in zip extraction"
- "Improve browser detection on Windows 11"

**MINOR: 0.0.2 → 0.1.0**
- "Add support for custom icon colors"
- "Add PWA library management feature"
- "Add remote URL installation capability"

**MAJOR: 0.9.0 → 1.0.0**
- "First stable release"
- "Change from single-file to multi-file package structure"
- "Remove deprecated command-line flags"

### Integration with Git Workflow

Version bumping happens BEFORE creating a release:

1. Complete all features/fixes in branch
2. Test thoroughly
3. Analyze changes and ask user about version bump type
4. Update `package.json` version
5. Commit version change
6. Create git tag
7. Push branch with tags
8. Create release with notes

### Verification Commands

```bash
# Check current version
grep '"version"' package.json

# Check if tags exist
git tag -l | tail -5

# View recent version changes
git log --oneline --grep="version" -10
```

### When You Forget

If changes were already committed without version bump:

1. Edit `package.json` manually with new version
2. Commit: `git add package.json && git commit -m "Bump version to vX.Y.Z"`
3. Tag: `git tag -a vX.Y.Z -m "Version X.Y.Z"`
4. Push: `git push && git push --tags`

### Human Override

Users can always override AI agent version decisions:
- Manually edit `package.json`
- Set specific version
- Document reasoning in commit message
- AI agents should defer to user judgment when corrected

### Current Version

**Version: 0.5.0** (Active Development)

**Version History:**
- **0.0.1** → **0.5.0** (Nov 20, 2025): MINOR bump
  - Rationale: Multiple significant new features added
  - Service worker architecture with offline shell page caching
  - Install button visibility improvements (disabled state, timeout fallback)
  - Comprehensive console logging for debugging
  - Documentation consolidation (USER_GUIDE.txt renamed)
  - Version display added to GUI (bottom-left ghost text)

Next releases:
- 0.5.X for bug fixes and minor improvements
- 0.6.0+ for new features (backwards compatible)
- 1.0.0 when stable and production-ready

**Versioning Workflow:**
1. AI agent identifies changes requiring version bump
2. AI agent proposes version bump to user with reasoning
3. User approves or rejects proposal
4. Only after approval: update package.json, GUI version label, README, USER_GUIDE.txt
5. Commit with clear version bump message
6. Tag release if appropriate

